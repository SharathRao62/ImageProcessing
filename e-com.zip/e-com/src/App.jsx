import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Footer from './components/Footer/footer';
import Navbar from './components/Navbar/Navbar';
import ContactBar from './components/ContactBar/contact';
import ContactUsForm from './components/ContactUs/ContactUsForm';
import AboutUs from './components/AboutUs/AboutUs'; // create this file as described earlier
import './App.css';

function App() {
  const [showContactForm, setShowContactForm] = useState(false);

  const openContactUsForm = () => setShowContactForm(true);
  const closeContactUsForm = () => setShowContactForm(false);

  return (
    <Router>
      <div className="page-wrapper">
        <ContactBar />
        <Navbar />

        {showContactForm && (
          <div className="modal-overlay">
            <div className="modal-content">
              <button className="close-btn" onClick={closeContactUsForm}>×</button>
              <ContactUsForm />
            </div>
          </div>
        )}

        <main className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<AboutUs />} />
            {/* Add more pages here if needed */}
          </Routes>
        </main>

        <Footer openContactUsForm={openContactUsForm} />
      </div>
    </Router>
  );
}

function Home() {
  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h2>Welcome to Snappy!</h2>
      <p>Your one-stop online shop for style and comfort.</p>
    </div>
  );
}

export default App;
