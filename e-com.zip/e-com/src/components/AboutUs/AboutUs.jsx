// import React from 'react';
// import './AboutUs.css';

// const AboutUs = () => {
//   return (
//     <div className="about-us-container">
//       <div className="about-us-header">
//         <h1>About Snappy</h1>
//         <p>Your one-stop destination for style, comfort, and quality.</p>
//       </div>

//       <section className="about-us-section">
//         <h2>Who We Are</h2>
//         <p>
//           Founded in 2022, Snappy is a modern e-commerce platform built to redefine the online shopping experience.
//           Whether you're looking for the latest fashion trends or timeless wardrobe essentials,
//           Snappy brings you high-quality products from top global brands like Nike, Adidas, and Puma.
//         </p>
//       </section>

//       <section className="about-us-section">
//         <h2>Our Mission</h2>
//         <p>
//           To empower every individual to express their personal style with ease and confidence — by making
//           quality fashion affordable and accessible to all.
//         </p>
//       </section>

//       <section className="about-us-section">
//         <h2>Why Shop with Us?</h2>
//         <ul>
//           <li>✅ Curated collections from trusted brands</li>
//           <li>✅ Fast & free shipping on most items</li>
//           <li>✅ 24/7 customer support</li>
//           <li>✅ Easy returns and exchanges</li>
//         </ul>
//       </section>

//       <section className="about-us-section">
//         <h2>Join the Snappy Community</h2>
//         <p>
//           We’re more than just a store — we’re a community of style lovers. Follow us on social media
//           and subscribe to our newsletter to get exclusive deals, trend alerts, and behind-the-scenes stories.
//         </p>
//       </section>
//     </div>
//   );
// };

// export default AboutUs;


import React from 'react';
import './AboutUs.css';

const AboutUs = () => {
  console.log('✅ AboutUs component loaded');
  return (
    <div className="about-us-container">
      <div className="about-us-header">
        <h1>About Snappy</h1>
        <p>Your one-stop destination for style, comfort, and quality.</p>
      </div>

      <section className="about-us-section">
        <h2>Who We Are</h2>
        <p>
          Founded in 2022, Snappy is a modern e-commerce platform built to redefine the online shopping experience.
          Whether you're looking for the latest fashion trends or timeless wardrobe essentials,
          Snappy brings you high-quality products from top global brands like Nike, Adidas, and Puma.
        </p>
      </section>

      <section className="about-us-section">
        <h2>Our Mission</h2>
        <p>
          To empower every individual to express their personal style with ease and confidence — by making
          quality fashion affordable and accessible to all.
        </p>
      </section>

      <section className="about-us-section">
        <h2>Why Shop with Us?</h2>
        <ul>
          <li>✅ Curated collections from trusted brands</li>
          <li>✅ Fast & free shipping on most items</li>
          <li>✅ 24/7 customer support</li>
          <li>✅ Easy returns and exchanges</li>
        </ul>
      </section>

      <section className="about-us-section">
        <h2>Join the Snappy Community</h2>
        <p>
          We’re more than just a store — we’re a community of style lovers. Follow us on social media
          and subscribe to our newsletter to get exclusive deals, trend alerts, and behind-the-scenes stories.
        </p>
      </section>
    </div>
  );
};

export default AboutUs;
