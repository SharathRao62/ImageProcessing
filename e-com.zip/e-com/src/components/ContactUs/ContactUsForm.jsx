import React from 'react';
import './ContactUsForm.css';

const ContactUsForm = () => {

  const handleNameInput = (e) => {
    let value = e.target.value.replace(/[^A-Za-z]/g, '');
    if (value.length > 0) {
      value = value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
    }
    e.target.value = value;
  };

  const handlePhoneInput = (e) => {
    let value = e.target.value.replace(/[^0-9]/g, '');
    if (value.length === 1 && !/[6-9]/.test(value)) {
      value = '';
    }
    e.target.value = value;
  };

  const handleEmailInput = (e) => {
    const value = e.target.value;
    const pattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.com$/;
    if (value && !pattern.test(value)) {
      e.target.setCustomValidity('Please enter a valid email id');
    } else {
      e.target.setCustomValidity('');
    }
  };

  const handleTextareaInput = (e) => {
    let value = e.target.value;
    if (value.length > 0) {
      value = value.charAt(0).toUpperCase() + value.slice(1);
    }
    e.target.value = value;
  };

  return (
    <div className="contact-container">
      <div className="contact-box">
        <h2>Get in Touch</h2>
        <p className="subtitle">Have a question or need help? Send us a message!</p>
        <form>
          <div className="form-row">
            <div className="form-group">
              <label>First Name</label>
              <input
                type="text"
                placeholder="Please enter first name..."
                pattern="[A-Za-z]*"
                onInput={handleNameInput}
              />
            </div>
            <div className="form-group">
              <label>Last Name</label>
              <input
                type="text"
                placeholder="Please enter last name..."
                pattern="[A-Za-z]*"
                onInput={handleNameInput}
              />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Email</label>
              <input type="email" placeholder="Please enter email..." onInput={handleEmailInput} />
            </div>
            <div className="form-group">
              <label>Phone Number</label>
              <input
                type="tel"
                placeholder="Please enter phone number..."
                inputMode="numeric"
                maxLength={10}
                onInput={handlePhoneInput}
              />
            </div>
          </div>
          <div className="form-group full-width">
            <label>What do you have in mind</label>
            <textarea rows="4" placeholder="Please enter query..." onInput={handleTextareaInput} />
          </div>
          <div className="form-group full-width">
            <button type="submit">Submit</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ContactUsForm;
