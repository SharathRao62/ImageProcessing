const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'Sharath',
    password: 'password',
    database: 'ems'
});

connection.connect((err) => {
    if (err) {
        console.error('❌ MySQL Connection Failed:', err.message);
    } else {
        console.log('✅ MySQL Connected Successfully!');
    }
});