const dbconfig = require('../config/dbConfig')
const Sequelize = require('sequelize')

var employee = dbconfig.define('employee', {

    id: {
        type: Sequelize.INTEGER,
        // allowNull: false
        primaryKey: true
    },
    first_name: Sequelize.STRING,   //connecting mysql with node js server
    middle_name: Sequelize.STRING,
    last_name: Sequelize.STRING,
    mobile_number: Sequelize.STRING,
    address_1: Sequelize.STRING,
    address_2: Sequelize.STRING,
    city: Sequelize.STRING,
    pincode: Sequelize.STRING,
    education: Sequelize.STRING,
    skills: Sequelize.STRING,
    experience: Sequelize.INTEGER,
    email: Sequelize.STRING,
    registration_number: Sequelize.STRING,
    email_sent: Sequelize.TINYINT,
    createdTime: Sequelize.DATE,
    updatedTime: Sequelize.DATE,
},
    {
        updatedAt: 'updatedTime',
        createdAt: 'createdTime',
        freezeTableName: true,
    });

module.exports = employee
