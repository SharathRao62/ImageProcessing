const dbconfig = require('../config/dbConfig')
const Sequelize = require('sequelize')

var login = dbconfig.define('user_login', {

    id: {
        type: Sequelize.INTEGER,
        // allowNull: false
        primaryKey: true
    },
    email: Sequelize.STRING,   
    password: Sequelize.STRING,
    createdTime: Sequelize.DATE,
    updatedTime: Sequelize.DATE,
},
    {
        updatedAt: 'updatedTime',
        createdAt: 'createdTime',
        freezeTableName: true,
    });

module.exports = login
