const nodemailer = require('nodemailer');
const { EMAIL } = require('../config/environConfig');

const sendRegistrationEmail = async (user, email, registrationNumber, logger) => {
    if (!email) {
        logger.error("No email provided for sending registration email.");
        return false;
    }

    let transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
            user: EMAIL.EMAIL_USER,
            pass: EMAIL.EMAIL_PASSWORD
        },
        tls: {
            rejectUnauthorized: false
        }
    });

    const mailOptions = {
        from: EMAIL.EMAIL_USER,
        to: email,
        subject: "Registration Confirmation",
        text: `Dear ${user},\n\nYour registration is successful! Your registration number is: ${registrationNumber}\n\nThank you!`
    };

    try {
        let info = await transporter.sendMail(mailOptions);
        logger.info(`Email sent successfully: ${info.response}`);

        // here  Update employees table with email status (1 if sent, 0 if failed)

        return true;
    } catch (error) {
        logger.error(`Email sending failed: ${error.message}`);
        return false;
    }
};



const processEmployeeRegistration = async (registration_number, employeeManageService, logger) => {
    if (!registration_number) {
        logger.error("Registration number is undefined.");
        return;
    }

    let condition1 = { registration_number };
    let emailData = await employeeManageService.getEmailData(condition1, ['email', 'first_name'], logger);
    logger.info(`emailData: ${JSON.stringify(emailData)}`);

    let email = emailData?.email || null;
    let user = emailData?.first_name || null;

    if (email) {
        let emailSent = await sendRegistrationEmail(user, email, registration_number, logger);
        
        // Update employees table with email status (1 if sent, 0 if failed)
        let updateStatus = emailSent ? 1 : 0;
        await employeeManageService.createEmployeeService({ registration_number, email_sent: updateStatus });
    } else {
        logger.error("Email not found. Cannot send registration email.");
    }
};

module.exports = { processEmployeeRegistration };
