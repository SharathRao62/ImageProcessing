const express = require('express');
const path = require("path");
const http = require("http");
const swaggerTools = require("swagger-tools");
const jsyaml = require("js-yaml");
const fs = require("fs");
const bodyParser = require('body-parser');
const cors = require('cors');
const Logger = require('./utils/logger');
require('dotenv/config'); // Load environment variables
require('./models/index');
const swaggerUi = require('swagger-ui-express');


const app = express();
const serverPort = 3000;
const logger = new Logger();

app.use(bodyParser.json());
app.use(cors({ origin: "*" }));

// Read and parse the Swagger YAML file
const swaggerYamlPath = path.join(__dirname, "api/swagger.yaml");
const swaggerDoc = jsyaml.load(fs.readFileSync(swaggerYamlPath, "utf8"));

// Define Swagger options
const options = {
  swaggerUi: path.join(__dirname, '/swagger.json'),
  controllers: path.join(__dirname, './api/controllers'),
  useStubs: process.env.NODE_ENV === 'development', // Use stubs in development mode
};

// Initialize Swagger middleware
swaggerTools.initializeMiddleware(swaggerDoc, (middleware) => {
  app.use(middleware.swaggerMetadata());
  app.use(middleware.swaggerValidator());
  app.use(middleware.swaggerRouter(options));
  app.use('/ems/docs', swaggerUi.serve, swaggerUi.setup(swaggerDoc));

  // Start HTTP server
  http.createServer(app).listen(serverPort, () => {
    const checkDate = new Date();
    const environment = process.env.NODE_ENV || 'development';

    logger.info(`Environment: ${environment}`);
    logger.info(`Server is running on http://localhost:${serverPort}`);
    logger.info(`Swagger UI available at http://localhost:${serverPort}/ems/docs`);
    logger.info(`Date/Time: ${checkDate}`);
  });
});

