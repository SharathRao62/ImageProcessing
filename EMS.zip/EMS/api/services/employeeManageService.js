const employee = require('../../models/employee');
const login = require('../../models/login');

async function createEmployeeService(payload, logger) {
    try {
        logger.info(`create_employee_service | ${JSON.stringify(payload)}`);
        let employeeAddition = await employee.create(payload);
        return employeeAddition;

    } catch (error) {
        logger.error(`createEmployeeService | Error creating employee ${error}`);
    }
}

const getMobileData = (condition, columns, logger) => {
    logger.info(`getMobileData | ${JSON.stringify(condition)}`);    // Log the condition properly
    return employee.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getMobileData | error | ${error}`);
        // throw error; // Ensure error is properly handled
    });
};

const getRegistrationNumber = (columns, logger) => {
    logger.info(`getRegistrationNumber | ${JSON.stringify(columns)}`);
    return employee.findOne({
        attributes: columns,
        order: [['CreatedTime', 'DESC']],
        raw: true,
    }).catch((error) => {
        logger.error(`getRegistrationNumber | error | ${error}`);
        // throw error; // Ensure error is properly handled
    });
};

const getEmployeeData = (condition, columns, logger) => {
    logger.info(`getEmployeeData | ${JSON.stringify(condition)}`); // Log the condition properly
    return employee.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getEmployeeData | error | ${error}`);
        // throw error; // Ensure error is properly handled
    });
};

const getEmailData = (condition1, columns, logger) => {
    logger.info(`getEmailData | ${JSON.stringify(columns)}`);
    return employee.findOne({
        attributes: columns,
        where: condition1,
        order: [['CreatedTime', 'DESC']],
        raw: true,
    }).catch((error) => {
        logger.error(`getEmailData | error | ${error}`);
        // throw error; // Ensure error is properly handled
    });
};

const userLogin = (condition, columns, logger) => {
    logger.info(`userLogin | ${JSON.stringify(condition)}`); // Log the condition properly
    return login.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`userLogin | error | ${error}`);
        // throw error; // Ensure error is properly handled
    });
};

async function RegisterUser(payload, logger) {
    try {
        logger.info(`RegisterUser | ${JSON.stringify(payload)}`);
        console.log(payload);

        let userRegister = await login.create(payload);
        return userRegister;

    } catch (error) {
        logger.error(`RegisterUser | Error creating employee: ${error}`);
        console.log(error);

    }
}

module.exports = {
    createEmployeeService,
    getMobileData,
    getRegistrationNumber,
    getEmployeeData,
    getEmailData,
    userLogin,
    RegisterUser,
}