const Logger = require("../../utils/logger");
const { writeJson } = require("../../utils/writer");
const { ENTERING_TO, CONTROLLER_METHOD, METHOD } = require('../../constants/constantLogger');
const userRegistrationBusiness = require('../business-logic/userRegistrationBusiness');

const userRegistration = async (req, res) => {
    const logger = new Logger('User Login');
    logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.EMPLOYEE_MANAGEMENT} | request ${JSON.stringify(req.body)}`);

    await userRegistrationBusiness.registrationUser(req.body).then(response => {
        writeJson(res, response)
    })
}
module.exports = { userRegistration }


// const employeeManage = async (req, res) => {
//     const logger = new Logger('Employee Details');
//     logger.info(`Processing Employee Management | Request: ${JSON.stringify(req.body)}`);

//     const response = await employeeManageBusiness.employeeManage(req.body);
//     res.json(response);
// };

// module.exports = { employeeManage };
