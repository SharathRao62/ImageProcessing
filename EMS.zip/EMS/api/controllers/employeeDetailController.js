const Logger = require("../../utils/logger");
const { writeJson } = require("../../utils/writer");
const { ENTERING_TO, CONTROLLER_METHOD, METHOD } = require('../../constants/constantLogger');
const employeeDetailBusiness = require('../business-logic/employeeDetailBusiness');

const employeeDetail = async (req, res) => {
    const logger = new Logger('Employee Details');
    logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.EMPLOYEE_MANAGEMENT} | request ${JSON.stringify(req.body)}`);

    await employeeDetailBusiness.employeeManage(req.body).then(response => {
        writeJson(res, response)
    })
}
module.exports = { employeeDetail }