const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE, UNAUTHORIZED } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
const employeeManageService = require('../services/employeeManageService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');

module.exports.userLogin = async (req) => {
    const logger = new Logger(`Product: EMS | Method: userLogin`);

    try {
        logger.info(` ${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.USER_LOGIN} | request |  ${JSON.stringify(req)}`);

        const condition = { email: req.email };
        
        let employeeData = await employeeManageService.userLogin(condition, ['email', 'password'], logger);
        logger.info(`employeeData | ${JSON.stringify(employeeData)}`);

        if (!employeeData) {
            return {
                status: STATUS_CODE.NOT_FOUND,
                message: 'Employee not found',
            };
        }
        // If email exists and password matches
        if (employeeData && employeeData.email === req.email && employeeData.password === req.password) {
            return {
                status: STATUS_CODE.SUCCESS,
                data: employeeData,
                message: 'Logged in Successfully'
            };
        } else {
            return {
                status: STATUS_CODE.UNAUTHORIZED,
                message: 'Invalid email or password',
            };
        }

    } catch (error) {
        // Catch and log any errors
        logger.error(`${ERROR_CODE.API_INTERNAL} | userLogin | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.USER_LOGIN_API_FAILED,
        };
    }
};
