const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
const employeeManageService = require('../services/employeeManageService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');
const { sendRegistrationEmail } = require('../../utils/email');

module.exports.employeeManage = async (req) => {
    const logger = new Logger("Product: EMS | Method: employeeRegistration");

    try {
        logger.info(` ${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.EMPLOYEE_MANAGEMENT} | request | ${JSON.stringify(req)}`);

        const condition = {
            mobile_number: req.mobile_number,
        };

        
        const condition2 = {
            email: req.email,
        };

        let emailDetails = await employeeManageService.getEmailDetails(condition2, ['email'], logger);
        logger.info(`emailDetails ${JSON.stringify(emailDetails)}`);

        // Check if email already exists
        if (emailDetails && emailDetails.email === req?.email) {
            logger.info("Email already exists in database");
            return {
                status: STATUS_CODE.BAD_REQUEST,
                message: "Email already used"
            };
        }

        let mobileData = await employeeManageService.getMobileData(condition, ['mobile_number'], logger);
        logger.info(`mobileData ${JSON.stringify(mobileData)}`);

        // Check if mobile number already exists
        if (mobileData && mobileData.mobile_number === req?.mobile_number) {
            logger.info("Mobile number already exists in database");
            return {
                status: STATUS_CODE.BAD_REQUEST,
                message: "Mobile number already exists"
            };
        }


        // Fetch the latest registration number
        let reportData = await employeeManageService.getRegistrationNumber(['registration_number'], logger);
        let currentNumber = reportData?.registration_number ?? 2025000;
        let registration_number = ++currentNumber;
        logger.info(`Registration Number Generated: ${registration_number}`);

        const payload = {
            ...req,
            registration_number: registration_number,
        };

        // Create Employee Data
        let employeeData = await employeeManageService.createEmployeeService(payload, logger);
        logger.info(`Employee Created: ${JSON.stringify(employeeData)}`);

        // Success Response
        const response = {
            status: STATUS_CODE.SUCCESS,
            registrationNumber: registration_number,
            message: 'Success'
        };

        //Email Logic
        let condition1 = { registration_number };

        let emailData = await employeeManageService.getEmailData(condition1, ['email', 'first_name'], logger);
        logger.info(`emailData ${JSON.stringify(emailData)}`);

        let email = emailData?.email || null;
        let user = emailData?.first_name || null;
        if (email) {
            sendRegistrationEmail(user, email, registration_number, logger);
            // logger.info(`emailSend ${JSON.stringify(emailSend)}`);

        } else {
            logger.error("Email not found. Cannot send registration email.");
        }

        return response;

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage | error: ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EMS_API_FAILED
        };
    }
};