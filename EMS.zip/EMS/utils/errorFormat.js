const errorFormat = (error) => {
  return (typeof error != 'string' ? (JSON.stringify(error) != '{}' ? JSON.stringify(error) : error) : error);
};

module.exports = {
  errorFormat,
};
