// const nodemailer = require('nodemailer');
// const { EMAIL } = require('../config/environConfig');

// const sendRegistrationEmail = (user, email, registrationNumber, logger) => {
//     if (!email) {
//         logger.error("No email provided for sending registration email.");
//         return;
//     }

//     var transporter = nodemailer.createTransport({
//         host: "smtp.gmail.com",
//         port: 465,
//         secure: true,
//         auth: {
//             email: EMAIL.EMAIL_USER,
//             password: EMAIL.EMAIL_PASSWORD
//         },
//         tls: {
//             rejectUnauthorized: false
//         }
//     });

//     const mailOptions = {
//         from: EMAIL.EMAIL_USER,
//         to: email,
//         subject: "Registration Confirmation",
//         text: `Dear ${user},\n\nYour Employee registration is successful! Your registration number is: ${registrationNumber}\n\nThank you!`
//     };

    // transporter.sendMail(mailOptions, async (error, info) => {
    //     if (error) {
    //         logger.error(`Email sending failed: ${error.message}`);
    //     } else {
    //         logger.info(`Email sent successfully: ${info.response}`);
    //         if (info.response && info.response.includes("OK")) {                    // Gmail usually returns '250' or 'OK'
    //             try {
    //                 const result = await Employee.update(
    //                     { email_sent: 1:0 },
    //                     { where: { registration_number: registrationNumber } }
    //                 );
    //                 logger.info(`Employee record updated successfully for registration number: ${registrationNumber}\ , affected rows: ${result[0]}`);
    //             } catch (error) {
    //                 logger.error(`Failed to update employee record: ${error.message}`);
    //             }
    //         }
    //     }
    // });


    // OR 

    // transporter.sendMail(mailOptions, async (error, info) => {
    //     let emailSentStatus = 0; // default status is 0 (not sent)
    
    //     if (error) {
    //         logger.error(`Email sending failed: ${error.message}`);
    //     } else {
    //         logger.info(`Email sent successfully: ${info.response}`);
    //         if (info.response && info.response.includes("OK")) {
    //             emailSentStatus = 1; // mark as sent
    //         }
    //     }
    
    //     try {
    //         const result = await Employee.update(
    //             { email_sent: emailSentStatus }, // set email_sent to either 1 or 0
    //             { where: { registration_number: registrationNumber } }
    //         );
    //         logger.info(`Employee record updated successfully for registration number: ${registrationNumber}, affected rows: ${result[0]}`);
    //     } catch (updateError) {
    //         logger.error(`Failed to update employee record: ${updateError.message}`);
    //     }
    // });
    
// };

// module.exports = { sendRegistrationEmail }


const nodemailer = require("nodemailer");
// const { Employee } = require("../models/employee"); // Adjust the import based on your project structure
const { EMAIL } = require("../config/environConfig"); // Ensure your config file has proper credentials

const sendRegistrationEmail = async (user, email, registrationNumber, logger) => {
    if (!email) {
        logger.error("No email provided for sending registration email.");
        return;
    }

    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: EMAIL.EMAIL_USER,
            pass: EMAIL.EMAIL_PASSWORD
        }
    });

    const mailOptions = {
        from: EMAIL.EMAIL_USER,
        to: email,
        subject: "Registration Confirmation",
        text: `Dear ${user},\n\nYour Employee registration is successful! Your registration number is: ${registrationNumber}\n\nThank you!`
    };

    
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            logger.error(`Email sending failed: ${error.message}`);
        } else {
            logger.info(`Email sent successfully: ${info.response}`);
        }
    });
};

module.exports = { sendRegistrationEmail };
