// import jwt from "jsonwebtoken";
// import crypto from "crypto";

// // 🔹 Secure 256-bit secret key (Use env variables in production)
// const secretKey = "a6b1c2d3e4f5g6h7i8j9k0l1m2n3o4p5q6r7s8t9u0v1w2";

// // 🔹 Generate a 10-character random lead_id
// const lead_id = crypto.randomBytes(5).toString("hex").slice(0, 10); // Ensures exactly 10 characters

// // 🔹 JWT Payload
// const payload = {
//     Product: "Device Management System",
//     lead_id: lead_id, // Assign the random 10-char ID
// };

// // 🔹 Function to Sign JWT
// const jwtSign = (payload, expiresIn = 60 * 40) => {
//     return jwt.sign(payload, secretKey, { expiresIn });
// };

// // 🔹 Generate Token
// const token = jwtSign(payload);

// console.log("🔹 Generated JWT:", token);
// console.log("🔹 Generated Lead ID:", lead_id);

// // 🔹 Verify JWT
// try {
//     const verified = jwt.verify(token, secretKey);
//     console.log("✅ JWT Verified:", verified);
// } catch (err) {
//     console.error("❌ JWT Verification Failed:", err.message);
// }

// // 🔹 Decode JWT (Without Verification)
// const jwtDecode = (token) => jwt.decode(token);

// console.log("🔹 Decoded JWT:", jwtDecode(token));


// const fs = require('fs');
// const mysql = require('mysql2');
// const csv = require('csv-parser');

// // DB connection
// const connection = mysql.createConnection({
//   host: 'localhost',
//   user: 'Sharath',
//   password: 'password',
//   database: 'dms',
// });

// // Path to CSV
// const xlsx = require('xlsx');

// // Load workbook
// const workbook = xlsx.readFile('C:/Users/HPadmin/Downloads/Untitled spreadsheet(1).xlsx');

// // Get the first sheet
// const sheetName = workbook.SheetNames[0];
// const sheet = workbook.Sheets[sheetName];

// // Convert sheet to JSON
// const data = xlsx.utils.sheet_to_json(sheet);

// // Now `data` is an array of objects — you can loop and insert into MySQL
// console.log(data);
// // Read CSV and insert into DB
// fs.createReadStream(filePath)
//   .pipe(csv())
//   .on('data', (row) => {
//     const {
//       item_barcode,
//       global_rnd_no,
//       bond_no,
//       hp_id,
//       serial_number,
//       model_number,
//       project_name,
//       make_oem,
//       phase,
//       family,
//       category,
//       owner,
//       owner_employee,
//       user,
//       received_date,
//       status,
//       last_tested,
//       toner_avl,
//       location_rack,
//       floor,
//       remarks,
//     } = row;

//     const query = `
//       INSERT INTO inventory_items (
//         item_barcode, global_rnd_no, bond_no, hp_id, serial_number, model_number,
//         project_name, make_oem, phase, family, category, owner, owner_employee, user,
//         received_date, status, last_tested, toner_avl, location_rack, floor, remarks
//       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
//     `;

//     const values = [
//       item_barcode, global_rnd_no, bond_no, hp_id, serial_number, model_number,
//       project_name, make_oem, phase, family, category, owner, owner_employee, user,
//       received_date, status, last_tested, toner_avl === '1' ? 1 : 0, location_rack, floor, remarks
//     ];

//     connection.query(query, values, (err) => {
//       if (err) console.error('Insert error:', err);
//     });
//   })
//   .on('end', () => {
//     console.log('CSV file successfully processed and inserted.');
//     connection.end();
//   });


// const xlsx = require('xlsx');
// const path = require('path');
// const { insertInventoryItem } = require('./models/InventoryItem');

// const filePath = path.resolve(__dirname, 'inventory.xlsx');
// const workbook = xlsx.readFile(filePath);
// const sheet = workbook.Sheets[workbook.SheetNames[0]];
// const rows = xlsx.utils.sheet_to_json(sheet);

// (async () => {
//   for (const row of rows) {
//     await insertInventoryItem({
//       item_barcode: row['Item Barcode'],
//       global_rnd_no: row['Global R&D No'],
//       bond_no: row['Bond No'],
//       hp_id: row['HP ID'],
//       serial_number: row['Serial Number'],
//       model_number: row['Model Number'],
//       project_name: row['Project Name'],
//       make_oem: row['Make/OEM'],
//       phase: row['Phase'],
//       family: row['Family'],
//       category: row['Category'],
//       owner: row['Owner'],
//       owner_employee: row['Owner Employee'],
//       user: row['User'],
//       received_date: row['Received Date'],
//       status: row['Status'],
//       last_tested: row['Last Tested'],
//       toner_avl: row['Toner Avl'],
//       location_rack: row['Location/Rack'],
//       floor: row['Floor'],
//       remarks: row['Remarks'],
//     });
//   }

//   console.log('All rows imported successfully!');
// })();



const xlsx = require('xlsx');
const mysql = require('mysql2/promise');
const path = require('path');
// const workbook = xlsx.readFile('C:/Users/HPadmin/Downloads/Untitled spreadsheet(1).xlsx');

(async () => {
    // Step 1: Load Excel file
    const filePath = path.resolve(__dirname, 'C:/Users/HPadmin/Downloads/Untitled spreadsheet(1).xlsx'); // make sure your file is here
    const workbook = xlsx.readFile(filePath);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = xlsx.utils.sheet_to_json(sheet);

    // Step 2: Connect to MySQL
    const connection = await mysql.createConnection({
        host: 'localhost',
        user: 'Sharath',
        password: 'password',
        database: 'dms',
    });

    console.log('👉 First row keys:', Object.keys(rows[0]));

    // Step 3: Insert rows
    for (const row of rows) {
        try {
          await connection.execute(
            `INSERT INTO inventory_items (
              item_barcode, global_rnd_no, bond_no, hp_id, serial_number,
              model_number, project_name, make_oem, phase, family,
              category, owner, owner_employee, user, received_date,
              status, last_tested, toner_avl, location_rack, floor, remarks
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              row.item_barcode || null,
              row.global_rnd_no || null,
              row.bond_no || null,
              row.hp_id || null,
              row.serial_number || null,
              row.model_number || null,
              row.project_name || null,
              row.make_oem || null,
              row.phase || null,
              row.family || null,
              row.category || null,
              row.owner || null,
              row.owner_employee || null,
              row.user || null,
              row.received_date || null,
              row.status || null,
              row.last_tested || null,
              row.toner_avl || null,
              row.location_rack || null,
              row.floor || null,
              row.remarks || null
            ]
          );
        } catch (err) {
          console.error('❌ Error inserting row:', row, '\n', err.message);
        }
      }
      
    console.log('✅ All data inserted.');
    await connection.end();
})();
