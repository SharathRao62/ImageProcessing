import jwt from "jsonwebtoken";
import crypto from "crypto";

// 🔹 Secure 256-bit secret key (Use env variables in production)
const secretKey = "a6b1c2d3e4f5g6h7i8j9k0l1m2n3o4p5q6r7s8t9u0v1w2";

// 🔹 Generate a 10-character random lead_id
const lead_id = crypto.randomBytes(5).toString("hex").slice(0, 10); // Ensures exactly 10 characters

// 🔹 JWT Payload
const payload = {
    Product: "Device Management System",
    lead_id: lead_id, // Assign the random 10-char ID
};

// 🔹 Function to Sign JWT
const jwtSign = (payload, expiresIn = 60 * 40) => {
    return jwt.sign(payload, secretKey, { expiresIn });
};

// 🔹 Generate Token
const token = jwtSign(payload);

console.log("🔹 Generated JWT:", token);
console.log("🔹 Generated Lead ID:", lead_id);

// 🔹 Verify JWT
try {
    const verified = jwt.verify(token, secretKey);
    console.log("✅ JWT Verified:", verified);
} catch (err) {
    console.error("❌ JWT Verification Failed:", err.message);
}

// 🔹 Decode JWT (Without Verification)
const jwtDecode = (token) => jwt.decode(token);

console.log("🔹 Decoded JWT:", jwtDecode(token));
