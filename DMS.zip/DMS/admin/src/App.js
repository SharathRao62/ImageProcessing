// import React from "react";
// import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
// import Sidebar from "./components/Sidebar/Sidebar";
// import Dashboard from "./components/Dashboard/Dashboard";
// import Devices from "./components/Devices/Devices";
// import Approval from "./components/Approval/Approval";
// import Deny from "./components/Deny/Deny";
// import Users from "./components/Users/Users";

// export default function App() {
  
//   return (
//     <Router>
//       <div style={{ display: "flex" }}>
//         <Sidebar />
//         <main style={{ flex: 1, padding: "20px" }}>
//           <Routes>
//             <Route path="/dashboard" element={<Dashboard />} />
//             <Route path="/devices" element={<Devices />} />
//             <Route path="/requests/approval" element={<Approval />} />
//             <Route path="/requests/deny" element={<Deny />} />
//             <Route path="/users" element={<Users />} />
//             <Route path="*" element={<Navigate to="/dashboard" replace />} />
//           </Routes>
//         </main>
//       </div>
//     </Router>
//   );
// }



import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Sidebar from "./components/Sidebar/Sidebar";
import Dashboard from "./components/Dashboard/Dashboard";
import Devices from "./components/Devices/Devices";
import Approval from "./components/Approval/Approval";
import Deny from "./components/Deny/Deny";
import Users from "./components/Users/Users";
import Login from "./components/Login/Login";
import Request from "./components/Request/Request";

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false); // control login status

  return (
    <Router>
      {!isLoggedIn ? (
        // Show Login page if not logged in
        <Login setIsLoggedIn={setIsLoggedIn} />
      ) : (
        // Show full app layout after login
        <div >
          <Sidebar />
          <main style={{ flex: 1, padding: "20px" }}>
            <Routes>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/devices" element={<Devices />} />
              <Route path="/requests/approval" element={<Approval />} />
              <Route path="/requests/deny" element={<Deny />} />
              <Route path="/users" element={<Users />} />
              <Route path="/requests" element={<Request/>} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </main>
        </div>
      )}
    </Router>
  );
}
