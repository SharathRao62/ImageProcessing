import React, { useState } from 'react';
import './Login.css';
import axios from 'axios';
import { FaEnvelope, FaLock, FaEye, FaEyeSlash, FaExclamationCircle } from 'react-icons/fa';
import Logo from 'D:/DMS/admin/src/Assets/Logo.jpg';
import Page from '../Page/Page';

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [loggedIn, setLoggedIn] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    if (errors[name]) {
      const updatedErrors = { ...errors };
      delete updatedErrors[name];
      setErrors(updatedErrors);
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    if (!value.trim()) {
      setErrors((prev) => ({
        ...prev,
        [name]: `${name.charAt(0).toUpperCase() + name.slice(1)} cannot be blank`,
      }));
    }
  };

  const handleSubmit = async () => {
    const newErrors = {};
    if (!form.email.trim()) newErrors.email = 'Email cannot be blank';
    if (!form.password.trim()) newErrors.password = 'Password cannot be blank';

    if (Object.keys(newErrors).length > 0) {
      setErrors((prev) => ({ ...prev, ...newErrors }));
      return;
    }

    const apiUrl = 'http://localhost:5000/api/v1/login';

    const payload = {
      email: form.email,
      password: form.password,
      role: 'admin', // attach the role
    };

    try {
      const response = await axios.post(apiUrl, payload);
       console.log('Login Response:', response.data);

      if (response.status === 200) {
        const { accessToken, refreshToken, role } = response.data;

        // Store tokens and role in localStorage
        localStorage.setItem('accessToken', accessToken);
        localStorage.setItem('refreshToken', refreshToken);
        localStorage.setItem('role', role || 'admin'); // fallback to 'admin' if not returned

        alert('Login successful!');
        setLoggedIn(true);
      }
    } catch (error) {
      console.error('Login failed:', error);
      alert(error.response?.data?.message || 'Login failed');
      
    }
  };

  if (loggedIn) {
    return <Page />;
  }

  return (
    <div className="login-page">
      <div className="form-container">
        <div className="left-side">
          <div className="logo">
            <img src={Logo} alt="Logo" />
          </div>
          <h2>Admin Login</h2>
          <p>Please enter your credentials to login</p>

          <div className="input-group">
            <FaEnvelope />
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={form.email}
              onChange={handleChange}
              onBlur={handleBlur}
            />
          </div>
          {errors.email && (
            <div className="error-message">
              <FaExclamationCircle className="error-icon" /> {errors.email}
            </div>
          )}

          <div className="input-group">
            <FaLock />
            <input
              type={showPassword ? 'text' : 'password'}
              name="password"
              placeholder="Password"
              value={form.password}
              onChange={handleChange}
              onBlur={handleBlur}
            />
            {showPassword ? (
              <FaEyeSlash className="eye-icon" onClick={() => setShowPassword(false)} />
            ) : (
              <FaEye className="eye-icon" onClick={() => setShowPassword(true)} />
            )}
          </div>
          {errors.password && (
            <div className="error-message">
              <FaExclamationCircle className="error-icon" /> {errors.password}
            </div>
          )}

          <button className="btn" onClick={handleSubmit}>
            Login
          </button>
        </div>
        <div className="right-side">{/* Optional right side design */}</div>
      </div>
    </div>
  );
};

export default Login;
