import React from 'react';
import Sidebar from '../Sidebar/Sidebar';
import Dashboard from '../Dashboard/Dashboard';
import Devices from '../Devices/Devices';
import Approval from '../Approval/Approval';
import Deny from '../Deny/Deny';
import Users from '../Users/Users';
import Request from '../Request/Request';


import { Routes, Route, Navigate } from 'react-router-dom';
import './Page.css';

const Page = () => {
  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <Sidebar />
      <div style={{ flex: 1, padding: '20px' }}>
        <Routes>
          {/* Welcome message for the root route */}
          <Route
            path="/"
            element={
              <div className="welcome-message">
                <h1>Welcome to Device Management System</h1>
              </div>
            }
          />
          {/* Dashboard Route */}
          <Route path="/dashboard" element={<Dashboard />} />
          {/* Devices Route */}
          <Route path="/devices" element={<Devices />} /> 
           {/* mydevice Route */}

             <Route path="/requests/approval" element={<Approval />} />

             <Route path="/requests/deny" element={<Deny />} />
              <Route path="/users" element={<Users />} />
              <Route path ='requests' element={<Request/>} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />

             

          
          {/* Redirect unknown paths to the welcome message */}
          {/* <Route path="*" element={<Navigate to="/" />} /> */}
        </Routes>
      </div>
    </div>
  );
};

export default Page;
