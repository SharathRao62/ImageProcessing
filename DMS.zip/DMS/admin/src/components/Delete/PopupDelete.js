import React, { useState } from "react";
import "./PopupDelete.css";

function PopupDelete({ device, onClose, onConfirm }) {
  const [isChecked, setIsChecked] = useState(false);

  const handleConfirmClick = () => {
    if (isChecked) {
      onConfirm(device._id);  // pass the device id to delete
    } else {
      alert("Please confirm by checking the box.");
    }
  };

  return (
    <>
      <div className="popup-delete-overlay" />
      <div className="popup-delete-container">
        <h2>Are you sure you want to delete this device?</h2>
        <p><strong>{device.device_name}</strong> (Global RND No: {device.global_rnd_no})</p>
        
        <label className="confirm-checkbox">
          <input
            type="checkbox"
            checked={isChecked}
            onChange={() => setIsChecked(!isChecked)}
          />
          Yes, I confirm to delete this device.
        </label>

        <div className="popup-delete-buttons">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button
            className="btn-delete"
            onClick={handleConfirmClick}
            disabled={!isChecked}
          >
            Delete
          </button>
        </div>
      </div>
    </>
  );
}

export default PopupDelete;
