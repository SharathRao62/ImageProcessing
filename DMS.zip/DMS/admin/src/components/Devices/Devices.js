// import React, { useState } from "react";
// import "./Devices.css"; // Using your existing CSS styles

// function Devices() {
//   const [searchTerm, setSearchTerm] = useState("");
//   const [devices, setDevices] = useState([]);
//   const [error, setError] = useState("");

//   const handleSearch = async () => {
//     if (searchTerm.trim().length < 3) {
//       setError("Please enter at least 3 letters.");
//       setDevices([]);
//       return;
//     }

//     setError("");
//     try {
//       const response = await fetch("http://localhost:5000/api/v1/deviceSearch", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ search_key: searchTerm }),
//       });

//       const result = await response.json();

//       if (response.status === 404 || result.status === 404) {
//         setDevices([]);
//         setError("No devices found.");
//       } else if (response.ok && result.status === 200) {
//         setDevices(result.data);
//         setError("");
//       } else {
//         setDevices([]);
//         setError("Unexpected error occurred.");
//       }
//     } catch (error) {
//       console.error("Fetch error:", error);
//       setError("Server error. Please try again later.");
//       setDevices([]);
//     }
//   };

//   return (
//     <div className="dashboard-container">
//       <h1>Devices Management</h1>

//       {/* <div className="search-section">
//         <input
//           className="search-input"
//           type="text"
//           placeholder="Search device by name..."
//           value={searchTerm}
//           onChange={(e) => setSearchTerm(e.target.value)}
//         />
//         <button className="search-button" onClick={handleSearch}>
//           Search
//         </button>
//         <button className="add-button" style={{ marginLeft: "10px" }}>
//           Add Device
//         </button>
//       </div> */}
//         <div className="search-section">
//         <input
//           type="text"
//           placeholder="Search by name..."
//           value={searchTerm}
//           onChange={(e) => setSearchTerm(e.target.value)}
//         />
//         <button onClick={handleSearch}>Search</button>
//         {error && <p className="error-message">{error}</p>}
//       </div>

//       {error && <p className="error-message">{error}</p>}

//       {devices.length > 0 && (
//         <div className="table-container">
//           <table className="devices-table">
//             <thead>
//               <tr>
//                 <th></th>
//                 <th>Device Name</th>
//                 <th>Model Number</th>
//                 <th>Global RND No</th>
//                 <th>Category</th>
               
//                 <th>Actions</th>
//               </tr>
//             </thead>
//             <tbody>
//               {devices.map((device, index) => (
//                 <tr key={index}>
//                   <td>
//                     <input type="checkbox" />
//                   </td>
//                   <td>{device.device_name}</td>
//                   <td>{device.model_number}</td>
//                   <td>{device.global_rnd_no}</td>
//                   <td>{device.category}</td>
               
//                   <td>
//                     <button className="action-button-modify">Modify</button>{" "}
//                     <button className="action-button-delete">Delete</button>
//                     {/* Toggle button removed as requested */}
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       )}
//     </div>
//   );
// }

// export default Devices;


// import React, { useState } from "react";
// import "./Devices.css";
// import PopupModify from "../Modify/PopupModify";

// function Devices() {
//   const [searchTerm, setSearchTerm] = useState("");
//   const [devices, setDevices] = useState([]);
//   const [error, setError] = useState("");
//   const [showPopup, setShowPopup] = useState(false);
//   const [selectedDevice, setSelectedDevice] = useState(null);

//   const handleSearch = async () => {
//     if (searchTerm.trim().length < 3) {
//       setError("Please enter at least 3 letters.");
//       setDevices([]);
//       return;
//     }

//     setError("");
//     try {
//       const response = await fetch("http://localhost:5000/api/v1/deviceSearch", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ search_key: searchTerm }),
//       });

//       const result = await response.json();

//       if (response.status === 404 || result.status === 404) {
//         setDevices([]);
//         setError("No devices found.");
//       } else if (response.ok && result.status === 200) {
//         setDevices(result.data);
//         setError("");
//       } else {
//         setDevices([]);
//         setError("Unexpected error occurred.");
//       }
//     } catch (error) {
//       console.error("Fetch error:", error);
//       setError("Server error. Please try again later.");
//       setDevices([]);
//     }
//   };

//   const handleModify = (device) => {
//     setSelectedDevice(device);
//     setShowPopup(true);
//   };

//   const handleSave = async (updatedDevice) => {
//     try {
//       const response = await fetch(`http://localhost:5000/api/v1/deviceUpdate/${updatedDevice._id}`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify(updatedDevice),
//       });

//       if (response.ok) {
//         // Update device list with the modified device
//         setDevices((prevDevices) =>
//           prevDevices.map((device) =>
//             device._id === updatedDevice._id ? updatedDevice : device
//           )
//         );
//         setShowPopup(false);
//       } else {
//         alert("Failed to update device.");
//       }
//     } catch (error) {
//       console.error("Update error:", error);
//       alert("Server error.");
//     }
//   };

//   return (
//     <div className="dashboard-container">
//       <h1>Devices Management</h1>

//       <div className="search-section">
//         <input
//           type="text"
//           placeholder="Search by name..."
//           value={searchTerm}
//           onChange={(e) => setSearchTerm(e.target.value)}
//         />
//         <button onClick={handleSearch}>Search</button>
//         {error && <p className="error-message">{error}</p>}
//       </div>

//       {devices.length > 0 && (
//         <div className="table-container">
//           <table className="devices-table">
//             <thead>
//               <tr>
//                 <th></th>
//                 <th>Device Name</th>
//                 <th>Model Number</th>
//                 <th>Global RND No</th>
//                 <th>Category</th>
//                 <th>Actions</th>
//               </tr>
//             </thead>
//             <tbody>
//               {devices.map((device, index) => (
//                 <tr key={index}>
//                   <td>
//                     <input type="checkbox" />
//                   </td>
//                   <td>{device.device_name}</td>
//                   <td>{device.model_number}</td>
//                   <td>{device.global_rnd_no}</td>
//                   <td>{device.category}</td>
//                   <td>
//                     <button 
//                       className="action-button-modify"
//                       onClick={() => handleModify(device)}
//                     >
//                       Modify
//                     </button>
//                     <button className="action-button-delete">Delete</button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       )}

//       {showPopup && selectedDevice && (
//         <PopupModify
//           device={selectedDevice}
//           onClose={() => setShowPopup(false)}
//           onSave={handleSave}
//         />
//       )}
//     </div>
//   );
// }

// export default Devices;
// import React, { useState } from "react";
// import "./Devices.css";
// import PopupModify from "../Modify/PopupModify";
// import PopupDelete from "../Delete/PopupDelete";  // Import PopupDelete

// function Devices() {
//   const [searchTerm, setSearchTerm] = useState("");
//   const [devices, setDevices] = useState([]);
//   const [error, setError] = useState("");
//   const [showPopup, setShowPopup] = useState(false);
//   const [showDeletePopup, setShowDeletePopup] = useState(false); // New state
//   const [selectedDevice, setSelectedDevice] = useState(null);
//   const [selectedGlobalId, setSelectedGlobalId] = useState(null);

//   const handleSearch = async () => {
//     if (searchTerm.trim().length < 3) {
//       setError("Please enter at least 3 letters.");
//       setDevices([]);
//       return;
//     }

//     setError("");
//     try {
//       const response = await fetch("http://localhost:5000/api/v1/deviceSearch", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ search_key: searchTerm }),
//       });

//       const result = await response.json();

//       if (response.status === 404 || result.status === 404) {
//         setDevices([]);
//         setError("No devices found.");
//       } else if (response.ok && result.status === 200) {
//         setDevices(result.data);
//         setError("");
//       } else {
//         setDevices([]);
//         setError("Unexpected error occurred.");
//       }
//     } catch (error) {
//       console.error("Fetch error:", error);
//       setError("Server error. Please try again later.");
//       setDevices([]);
//     }
//   };

//   const handleModify = (device) => {
//     setSelectedDevice(device);
//     setShowPopup(true);
//   };

//   const handleDeleteClick = (device) => {
//     setSelectedDevice(device);
//     setShowDeletePopup(true);
//   };

//   const handleDeleteConfirm = async (deviceId) => {
//     try {
//       const response = await fetch(
//         `http://localhost:5000/api/v1/deviceDelete/${deviceId}`,
//         {
//           method: "DELETE",
//         }
//       );

//       if (response.ok) {
//         // Remove deleted device from state
//         setDevices((prevDevices) =>
//           prevDevices.filter((device) => device._id !== deviceId)
//         );
//         setShowDeletePopup(false);
//         setSelectedGlobalId(null);
//         setSelectedDevice(null);
//       } else {
//         alert("Failed to delete device.");
//       }
//     } catch (error) {
//       console.error("Delete error:", error);
//       alert("Server error.");
//     }
//   };

//   const handleSave = async (updatedDevice) => {
//     try {
//       const response = await fetch(
//         `http://localhost:5000/api/v1/deviceUpdate/${updatedDevice._id}`,
//         {
//           method: "PUT",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify(updatedDevice),
//         }
//       );

//       if (response.ok) {
//         setDevices((prevDevices) =>
//           prevDevices.map((device) =>
//             device._id === updatedDevice._id ? updatedDevice : device
//           )
//         );
//         setShowPopup(false);
//       } else {
//         alert("Failed to update device.");
//       }
//     } catch (error) {
//       console.error("Update error:", error);
//       alert("Server error.");
//     }
//   };

//   return (
//     <div className="dashboard-container">
//       <h1>Devices Management</h1>

//       <div className="search-section">
//         <input
//           type="text"
//           placeholder="Search by name..."
//           value={searchTerm}
//           onChange={(e) => setSearchTerm(e.target.value)}
//         />
//         <button onClick={handleSearch}>Search</button>
//         {error && <p className="error-message">{error}</p>}
//       </div>

//       {devices.length > 0 && (
//         <div className="table-container">
//           <table className="devices-table">
//             <thead>
//               <tr>
//                 <th></th>
//                 <th>Device Name</th>
//                 <th>Model Number</th>
//                 <th>Global RND No</th>
//                 <th>Category</th>
//                 <th>Actions</th>
//               </tr>
//             </thead>
//             <tbody>
//               {devices.map((device, index) => (
//                 <tr key={index}>
//                   <td>
//                     <input
//                       type="checkbox"
//                       checked={selectedGlobalId === device.global_rnd_no}
//                       onChange={() =>
//                         setSelectedGlobalId(
//                           selectedGlobalId === device.global_rnd_no
//                             ? null
//                             : device.global_rnd_no
//                         )
//                       }
//                     />
//                   </td>
//                   <td>{device.device_name}</td>
//                   <td>{device.model_number}</td>
//                   <td>{device.global_rnd_no}</td>
//                   <td>{device.category}</td>
//                   <td>
//                     <button
//                       className="action-button-modify"
//                       onClick={() => handleModify(device)}
//                       disabled={selectedGlobalId !== device.global_rnd_no}
//                     >
//                       Modify
//                     </button>
//                     <button
//                       className="action-button-delete"
//                       disabled={selectedGlobalId !== device.global_rnd_no}
//                       onClick={() => handleDeleteClick(device)}
//                     >
//                       Delete
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       )}

//       {showPopup && selectedDevice && (
//         <PopupModify
//           device={selectedDevice}
//           onClose={() => setShowPopup(false)}
//           onSave={handleSave}
//         />
//       )}

//       {showDeletePopup && selectedDevice && (
//         <PopupDelete
//           device={selectedDevice}
//           onClose={() => setShowDeletePopup(false)}
//           onConfirm={handleDeleteConfirm}
//         />
//       )}
//     </div>
//   );
// }

// export default Devices;

import React, { useState } from "react";
import "./Devices.css";

import PopupModify from "../Modify/PopupModify";
import PopupDelete from "../Delete/PopupDelete";  // Import PopupDelete

function Devices() {
  const [searchTerm, setSearchTerm] = useState("");
  const [devices, setDevices] = useState([]);
  const [error, setError] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const [showDeletePopup, setShowDeletePopup] = useState(false); // New state
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [selectedGlobalId, setSelectedGlobalId] = useState(null);

  const handleSearch = async () => {
    if (searchTerm.trim().length < 3) {
      setError("Please enter at least 3 letters.");
      setDevices([]);
      return;
    }

    setError("");
    try {
      const response = await fetch("http://localhost:5000/api/v1/deviceSearch", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ search_key: searchTerm }),
      });

      const result = await response.json();

      if (response.status === 404 || result.status === 404) {
        setDevices([]);
        setError("No devices found.");
      } else if (response.ok && result.status === 200) {
        setDevices(result.data);
        setError("");
      } else {
        setDevices([]);
        setError("Unexpected error occurred.");
      }
    } catch (error) {
      console.error("Fetch error:", error);
      setError("Server error. Please try again later.");
      setDevices([]);
    }
  };

  const handleModify = (device) => {
    setSelectedDevice(device);
    setShowPopup(true);
  };

  const handleDeleteClick = (device) => {
    setSelectedDevice(device);
    setShowDeletePopup(true);
  };

  const handleDeleteConfirm = async (deviceId) => {
    try {
      const response = await fetch( `http://localhost:5000/api/v1/deviceDelete/${deviceId}`,
        {
          method: "DELETE",
        }
      );

      if (response.ok) {
        // Remove deleted device from state
        setDevices((prevDevices) =>
          prevDevices.filter((device) => device._id !== deviceId)
        );
        setShowDeletePopup(false);
        setSelectedGlobalId(null);
        setSelectedDevice(null);
      } else {
        alert("Failed to delete device.");
      }
    } catch (error) {
      console.error("Delete error:", error);
      alert("Server error.");
    }
  };

  const handleSave = async (updatedDevice) => {
    try {
      const response = await fetch(`http://localhost:5000/api/v1/deviceUpdate/${updatedDevice._id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(updatedDevice),
        }
      );

      if (response.ok) {
        setDevices((prevDevices) =>
          prevDevices.map((device) =>
            device._id === updatedDevice._id ? updatedDevice : device
          )
        );
        setShowPopup(false);
      } else {
        alert("Failed to update device.");
      }
    } catch (error) {
      console.error("Update error:", error);
      alert("Server error.");
    }
  };

  return (
    <div className="dashboard-container">
      <h1>Devices Management</h1>

      <div className="search-section">
        <input
          type="text"
          placeholder="Search by name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button onClick={handleSearch}>Search</button>
        {error && <p className="error-message">{error}</p>}
      </div>

      {devices.length > 0 && (
        <div className="table-container">
          <table className="devices-table">
            <thead>
              <tr>
                <th></th>
                <th>Device Name</th>
                <th>Model Number</th>
                <th>Global RND No</th>
                <th>Category</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {devices.map((device, index) => (
                <tr key={index}>
                  <td>
                    <input
                      type="checkbox"
                      checked={selectedGlobalId === device.global_rnd_no}
                      onChange={() =>
                        setSelectedGlobalId(
                          selectedGlobalId === device.global_rnd_no
                            ? null
                            : device.global_rnd_no
                        )
                      }
                    />
                  </td>
                  <td>{device.device_name}</td>
                  <td>{device.model_number}</td>
                  <td>{device.global_rnd_no}</td>
                  <td>{device.category}</td>
                  <td>
                    <button
                      className="action-button-modify"
                      onClick={() => handleModify(device)}
                      disabled={selectedGlobalId !== device.global_rnd_no}
                    >
                      Modify
                    </button>
                    <button
                      className="action-button-delete"
                      disabled={selectedGlobalId !== device.global_rnd_no}
                      onClick={() => handleDeleteClick(device)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showPopup && selectedDevice && (
        <PopupModify
          device={selectedDevice}
          onClose={() => setShowPopup(false)}
          onSave={handleSave}
        />
      )}

      {showDeletePopup && selectedDevice && (
        <PopupDelete
          device={selectedDevice}
          onClose={() => setShowDeletePopup(false)}
          onConfirm={handleDeleteConfirm}
        />
      )}
    </div>
  );
}

export default Devices; 