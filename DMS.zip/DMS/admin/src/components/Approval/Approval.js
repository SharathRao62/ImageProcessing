import React, { useEffect, useState } from 'react';
import './Approval.css';

const Approval = () => {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((res) => res.json())
      .then((data) => setRequests(data))
      .catch((err) => console.error('API error:', err));
  }, []);

  const handleApproval = (id, action) => {
    alert(`Request ${id} has been ${action}`);
    // Here you can call your backend API to update the status
  };

  return (
    <div className="dashboard-container">
      <h1>Device Approval List</h1>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>SI NO</th>
              <th>Request Id</th>
              <th>Device Name</th>
              <th>Model Number</th>
              <th>Global RND No</th>
              <th>Category</th>
              <th>Status</th>
              
              
            </tr>
          </thead>
          <tbody>
            {requests.map((req, index) => (
              <tr key={req.id}>
                <td>{index + 1}</td>
                <td>REQ{req.id.toString().padStart(9, '0')}</td>
                <td>{req.name}</td>
                <td>Model_{req.id}</td>
                <td>GRND{1000 + req.id}</td>
                <td>{req.company.bs.split(' ')[0]}</td>
               
                <td>Approved</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Approval;
