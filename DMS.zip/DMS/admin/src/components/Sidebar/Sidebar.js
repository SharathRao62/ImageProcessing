import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Sidebar.css";
import {
  FaTachometerAlt,
  FaMicrochip,
  FaCheckCircle,
  FaTimesCircle,
  FaUser,
  FaClipboardList, // Icon for Requests
} from "react-icons/fa";

export default function Sidebar() {
  const [activeMenu, setActiveMenu] = useState("");

  const handleMenuClick = (menu) => {
    setActiveMenu(menu);
  };

  return (
    <div className="sidebar">
      <h3>Admin Panel</h3>
      <ul className="ul-a">
        <li className={activeMenu === "dashboard" ? "active" : ""} onClick={() => handleMenuClick("dashboard")}>
          <Link to="/dashboard">
            <FaTachometerAlt className="icon" />
            Dashboard
          </Link>
        </li>

        <li className={activeMenu === "devices" ? "active" : ""} onClick={() => handleMenuClick("devices")}>
          <Link to="/devices">
            <FaMicrochip className="icon" />
            Devices
          </Link>
        </li>

        <li className={activeMenu === "requests" ? "active" : ""} onClick={() => handleMenuClick("requests")}>
          <Link to="/requests">
            <FaClipboardList className="icon" />
            Requests
          </Link>
        </li>

        <li className={activeMenu === "approval" ? "active" : ""} onClick={() => handleMenuClick("approval")}>
          <Link to="/requests/approval">
            <FaCheckCircle className="icon" />
            Approval
          </Link>
        </li>

        <li className={activeMenu === "deny" ? "active" : ""} onClick={() => handleMenuClick("deny")}>
          <Link to="/requests/deny">
            <FaTimesCircle className="icon" />
            Deny
          </Link>
        </li>

        <li className={activeMenu === "users" ? "active" : ""} onClick={() => handleMenuClick("users")}>
          <Link to="/users">
            <FaUser className="icon" />
            Users
          </Link>
        </li>
      </ul>
    </div>
  );
}
