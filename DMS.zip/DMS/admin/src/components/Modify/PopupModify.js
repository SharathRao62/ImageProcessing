// src/popup/PopupModify.js
import React, { useState, useEffect } from "react";
import "./PopupModify.css";

function PopupModify({ device, onClose, onSave }) {
  const [formData, setFormData] = useState({
    device_name: "",
    model_number: "",
    global_rnd_no: "",
    category: ""
  });

  useEffect(() => {
    if (device) {
      setFormData({
        device_name: device.device_name,
        model_number: device.model_number,
       
      });
    }
  }, [device]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    onSave({ ...device, ...formData });
  };

  return (
    <div className="popup-overlay">
      <div className="popup-box">
        <h2>Modify Device</h2>
        <label>
          Device Name:
          <input type="text" name="device_name" value={formData.device_name} onChange={handleChange} />
        </label>
        <label>
          Model Number:
          <input type="text" name="model_number" value={formData.model_number} onChange={handleChange} />
        </label>
        <label>
          Global RND No:
          <input type="text" name="global_rnd_no" value={formData.global_rnd_no} onChange={handleChange} />
        </label>
        <label>
          Category:
          <input type="text" name="category" value={formData.category} onChange={handleChange} />
        </label>
        <div className="popup-actions">
          <button className="save-button" onClick={handleSubmit}>Submit</button>
          <button className="cancel-button" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}

export default PopupModify;
