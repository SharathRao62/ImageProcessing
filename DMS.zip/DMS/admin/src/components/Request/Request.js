import React, { useEffect, useState } from 'react';
import './Request.css';

const Request = () => {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    // Replace with your real API when ready
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((res) => res.json())
      .then((data) => setRequests(data))
      .catch((err) => console.error('API error:', err));
  }, []);

  const handleAction = (id, action) => {
    alert(`Request ${id} has been ${action}`);
    // Here you can add a fetch/axios call to update request status in your backend
  };

  return (
    <div className="request-container">
      <h1>Device Requests</h1>

      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>SI NO</th>
              <th>Request ID</th>
              <th>Device Name</th>
              <th>Model Number</th>
              <th>Global RND No</th>
              <th>Category</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {requests.map((req, index) => (
              <tr key={req.id}>
                <td>{index + 1}</td>
                <td>REQ{req.id.toString().padStart(5, '0')}</td>
                <td>{req.name}</td>
                <td>Model_{req.id}</td>
                <td>GRND{1000 + req.id}</td>
                <td>{req.company.bs.split(' ')[0]}</td>
                <td>
                  <button
                    className="approve-button"
                    onClick={() => handleAction(req.id, 'Approved')}
                  >
                    Approve
                  </button>
                  <button
                    className="deny-button"
                    onClick={() => handleAction(req.id, 'Denied')}
                  >
                    Deny
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Request;
