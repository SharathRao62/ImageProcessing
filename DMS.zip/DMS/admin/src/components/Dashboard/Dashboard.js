import React from "react";
import "./Dashboard.css";
import { FaUser, FaTasks, FaServer, FaWallet } from "react-icons/fa";

export default function Dashboard() {
  return (
    <div className="dashboard">
      <h1>Dashboard Overview</h1>
      <div className="card-grid">
        <div className="card green">
          <FaWallet className="icon" />
          <p className="label">Total Devices</p>
          <h3 className="heading">120</h3>
        </div>
        <div className="card pink">
          <FaUser className="icon" />
          <p className="label">Total Users</p>
          <h3 className="heading">45</h3>
        </div>
       
        <div className="card blue">
          <FaServer className="icon" />
          <p className="label">Active Devices</p>
          <h3 className="heading">100</h3>
        </div>
        <div className="card purple">
          <FaTasks className="icon" />
          <p className="label">Inactive Devices</p>
          <h3 className="heading">20</h3>
        </div>
        
      </div>
    </div>
  );
}
