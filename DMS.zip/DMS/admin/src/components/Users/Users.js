import React, { useEffect, useState } from "react";
import "./Users.css";

export default function Users() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch("'https://dummyjson.com/users'")
      .then((res) => res.json())
      .then((data) => {
        // Adjust this if your API wraps the user data inside a property like `data.users`
        setUsers(data);
      })
      .catch((error) => console.error("Error fetching users:", error));
  }, []);

  const handleDelete = (id) => {
    // You can call your delete API here
    alert(`User with ID ${id} deleted`);
  };

  return (
    <div className="users">
      <h2>User Management</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th><th>Email</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, index) => (
            <tr key={index}>
              <td>{user.firstName || "N/A"}</td>
              <td>{user.email || "N/A"}</td>
              <td>
                <button onClick={() => handleDelete(user._id || index)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
