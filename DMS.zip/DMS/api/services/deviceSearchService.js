const devices = require('../../models/devices'); // Make sure it's "devices" if that's your model name
const device = require('../../models/device'); // Make sure it's "devices" if that's your model name

const getDeviceData = (condition, columns, logger) => {
    logger.info(`getDeviceData: ${JSON.stringify(condition)}`);    // Log the condition properly
    return devices.findAll({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getDeviceData | error | ${error}`);
        throw error; // Ensure error is properly handled
    });
};


const getDeviceData1 = (condition, columns, logger) => {
    logger.info(`getDeviceData: ${JSON.stringify(condition)}`);
    return device.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getDeviceData | error | ${error}`);
        throw error;
    });
};


const updateDeviceService = (updateData, condition) => {
    return device.update(updateData,
        {
            where: condition,
            individualHooks: true,
        }
    ).catch((err) => {
        throw err;
    });
};


const createDeviceService = (payload) => {
    return device.create(payload) 
        .then((newRequest) => {
            return newRequest; 
        })
        .catch((error) => {
            throw error; 
        });
};


module.exports = {
    getDeviceData,
    getDeviceData1,
    updateDeviceService,
    createDeviceService
}
