const devices = require('../../models/devices'); // Make sure it's "devices" if that's your model name
const user_requested_device = require('../../models/user_requested_device'); // Make sure it's "devices" if that's your model name

const getDeviceData = (condition, columns, logger) => {
    logger.info(`getDeviceData: ${JSON.stringify(condition)}`);    // Log the condition properly
    return devices.findAll({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getDeviceData | error | ${error}`);
    });
};


const getDeviceDetails = (condition, columns, logger) => {
    logger.info(`getDeviceData: ${JSON.stringify(condition)}`);
    return device.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getDeviceData | error | ${error}`);
    });
};


const updateDeviceService = (updateData, condition) => {
    return device.update(updateData,
        {
            where: condition,
            individualHooks: true,
        }
    ).catch((error) => {
        logger.error(`updateDeviceService | error | ${error}`);
    });
};


const createDeviceService = (payload, logger) => {
    return user_requested_device.create(payload)
        .then((newRequest) => {
            return newRequest;
        }).catch((error) => {
            logger.error(`createDeviceService | error | ${error}`);
        });
};


module.exports = {
    getDeviceData,
    getDeviceDetails,
    updateDeviceService,
    createDeviceService,
}