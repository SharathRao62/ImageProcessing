const login = require('../../models/login');

const userLogin = (condition, columns, logger) => {
    logger.info(`userLogin | ${JSON.stringify(condition)}`);
    return login.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`userLogin | error | ${error}`);
    });
};

async function registerUser(payload, logger) {
    try {
        logger.info(`registerUseraaaaaaaaaaaaaaaa | ${JSON.stringify(payload)}`);
        let userRegister = await login.create(payload);
        return userRegister;
    } catch (error) {
        logger.error(`registerUser | Error creating employee: ${error}`);
    }
}

// async function registerUser(payload, logger) {
//     try {
//         logger.info(`registerUser | Payload: ${JSON.stringify(payload)}`);
//         let userRegister = await login.create(payload);
//         console.log('User created:', userRegister);
//         return userRegister;
//     } catch (error) {
//         logger.error(`registerUser | Error: ${error.message}`);
//         console.error(error); // <-- important
//         return null;
//     }
// }

module.exports = {
    userLogin,
    registerUser,
}