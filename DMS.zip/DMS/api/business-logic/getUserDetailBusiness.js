const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');

const deviceSearchService = require('../services/deviceSearchService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');
const moment = require('moment');
const { sendRegistrationEmail } = require('../../utils/email');

module.exports.getUserDetail = async (req) => {
    const logger = new Logger(`Product: DMS | Method: getUserDetails`);

    try {
        logger.info(`Entering ${BUSINESS_LOGIC_METHOD} | METHOD: getUserDetails | ${JSON.stringify(req)}`);

        const condition = {
            request_id: req.requestId,
        };

        let updateData = {
            request_date: req.requestDate,
        };

        let userData = await deviceSearchService.getDeviceDetails(condition, ['request_id', 'request_date', 'device_name', 'name', 'email'], logger);
        logger.info(`userData ${JSON.stringify(userData)}`);


        if (userData && userData.request_id) {
            let deviceData = await deviceSearchService.updateDeviceService(updateData, condition)
            logger.info(`deviceData ${JSON.stringify(deviceData)}`);

            return {
                status: STATUS_CODE.SUCCESS,
                message: 'User Data Updated Successfully',
            };
        }
    }
    catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.GET_USER_DETAILS_API_FAILED,
        };
    }
};
