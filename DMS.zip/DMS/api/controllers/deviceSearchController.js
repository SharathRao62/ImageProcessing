const Logger = require("../../utils/logger");
const { writeJson } = require("../../utils/writer");
const { ENTERING_TO, CONTROLLER_METHOD, METHOD } = require('../../constants/constantLogger');
const deviceSearchBusiness = require('../business-logic/deviceSearchBusiness');

const deviceSearch = async (req, res) => {

    const logger = new Logger();
    logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.DEVICE_SEARCH} | request ${JSON.stringify(req.body)}`);

    await deviceSearchBusiness.deviceSearch(req.body).then(response => {
        writeJson(res, response)
    })
}
module.exports = { deviceSearch }

