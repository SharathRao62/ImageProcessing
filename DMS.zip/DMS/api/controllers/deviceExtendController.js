const Logger = require("../../utils/logger");
const { writeJson } = require("../../utils/writer");
const { ENTERING_TO, CONTROLLER_METHOD, METHOD } = require('../../constants/constantLogger');
const deviceExtendBusiness = require('../business-logic/deviceExtendBusiness');

const deviceExtend = async (req, res) => {

    const logger = new Logger('Employee Details');
    logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.EMPLOYEE_MANAGEMENT} | request ${JSON.stringify(req.body)}`);

    await deviceExtendBusiness.deviceExtend(req.body).then(response => {
        writeJson(res, response)
    })
}
module.exports = { deviceExtend }
