const Logger = require("../../utils/logger");
const { writeJson } = require("../../utils/writer");
const { ENTERING_TO, CONTROLLER_METHOD, METHOD } = require('../../constants/constantLogger');
const requestDeviceBusiness = require('../business-logic/requestDeviceBusiness');
const logger = new Logger(`Product : DMS | Method : DMS_DETAILS `);
logger.info('DMS Enter')

const requestDevice = async (req, res) => {

    const logger = new Logger('Device Details');
    logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.USER_DETAILS} | request ${JSON.stringify(req.body)}`);

    await requestDeviceBusiness.requestDevice
        (req.body).then(response => {
            writeJson(res, response)
        })
}
module.exports = { requestDevice }

