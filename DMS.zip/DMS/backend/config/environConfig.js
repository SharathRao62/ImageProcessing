require('dotenv').config(); // Load environment variables

const Logger = require('../utils/logger'); // Import the Logger
const logger = new Logger(); // Initialize Logger

const env = process.env.NODE_ENV || 'development'; // Set environment

logger.info(`Using environment: ${env}`); // Log the environment

const environConfig = {
    development: {
        database: process.env.DB_NAME || 'dms',
        username: process.env.DB_USER || 'dhanya',
        password: process.env.DB_PASS || 'mypassword',
        host: process.env.DB_HOST || 'localhost',
    },
    qa: {
        database: process.env.DB_NAME || 'dms',
        username: process.env.DB_USER || 'dhanya',
        password: process.env.DB_PASS || 'mypassword',
        host: process.env.DB_HOST || 'localhost',
    },
};


const EMAIL = {
    EMAIL_USER: "techsudo34@gmail.com",
    EMAIL_PASSWORD: "qshlopxwpynwwqmm"
};


module.exports = { config: environConfig[env], env, EMAIL };
