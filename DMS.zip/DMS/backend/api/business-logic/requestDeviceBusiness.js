const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const deviceSearchService = require('../services/deviceSearchService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');
const { v4: uuidv4 } = require('uuid');  // Import UUID library for generating unique IDs
const { sendRegistrationEmail } = require('../../utils/email');
const moment = require('moment');

module.exports.requestDevice = async (req) => {
    const logger = new Logger(`Product : DMS | Method : requestDevice`);

    try {
        logger.info(` ${ENTERING_TO} ${BUSINESS_LOGIC_METHOD} | METHOD : requestDevice | ${JSON.stringify(req)}`);

        // Generate a unique requestId (UUID)
        const generateRequestId = () => { return 'REQ' + uuidv4().replace(/\D/g, '').substring(0, 9); };
        logger.info(`generateRequestId | ${generateRequestId()}`);
        let requestId = generateRequestId();

        let formattedDate = moment(req.request_date, 'DD-MM-YYYY').format('YYYY-MM-DD');
        logger.info(`formattedDate | ${JSON.stringify(formattedDate)}`);

        const payload = {
            ...req,
            request_id: requestId,
            request_date: formattedDate, // overwrite with the formatted date
        };
        logger.info(`payload | ${JSON.stringify(payload)}`);

        let deviceData = await deviceSearchService.createDeviceService(payload, logger);
        logger.info(`deviceData | ${JSON.stringify(deviceData)}`);

        let email = req.email || null;
        let userName = req.name || null;
        let reqId = requestId || null;
        let deviceName = req.device_name || null;


        if (req && req.email) {
            sendRegistrationEmail(userName, email, reqId, deviceName, logger);
        } else {
            logger.error("Email not found. Cannot send email.");
        }

        return {
            status: STATUS_CODE.SUCCESS,
            requestId: payload.request_id, // Return the generated requestId here
            message: 'Success'
        };

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.REQUEST_DEVICE_API_FAILED
        };
    }
};
