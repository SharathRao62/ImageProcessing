const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE, UNAUTHORIZED } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
const loginSerice = require('../services/loginSerice');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');
const bcrypt = require('bcrypt');

module.exports.registrationUser = async (req) => {
    const logger = new Logger(`Product: EMS | Method: registrationUser`);

    try {
        logger.info(` ${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.USER_LOGIN} | request |  ${JSON.stringify(req)}`);

        const condition = { email: req.email };

        // Check if the email is already in use
        let emailData = await loginSerice.userRegistration(condition, ['email'], logger);
        logger.info(`emailData | ${JSON.stringify(emailData)}`);

        if (emailData && emailData.email === req.email) {
            return {
                status: STATUS_CODE.CONFLICT, // 409 Conflict
                message: 'Email already used',
            };
        }

        let hashedPassword;
        if (req.password) {
            const saltRounds = 10;
            hashedPassword = await bcrypt.hash(req.password, saltRounds);
        }

        let payload = {
            email: req.email,
            password: hashedPassword
        };

        let employeeData = await loginSerice.registerUser(payload, logger);
        logger.info(`employeeData | ${JSON.stringify(employeeData)}`);

        return {
            status: STATUS_CODE.SUCCESS,
            message: 'User Registration Successfully'
        };
    } catch (error) {
        // Catch and log any errors
        logger.error(`${ERROR_CODE.API_INTERNAL} | userLogin | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.USER_LOGIN_API_FAILED,
        };
    }
};
