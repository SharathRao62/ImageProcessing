const mysql = require('mysql2/promise');

// Create MySQL pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'your_mysql_user',
  password: 'your_mysql_password',
  database: 'your_database_name',
});

const insertInventoryItem = async (item) => {
  const query = `
    INSERT INTO inventory_items (
      item_barcode, global_rnd_no, bond_no, hp_id, serial_number, model_number,
      project_name, make_oem, phase, family, category, owner, owner_employee, user,
      received_date, status, last_tested, toner_avl, location_rack, floor, remarks
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  const values = [
    item.item_barcode, item.global_rnd_no, item.bond_no, item.hp_id,
    item.serial_number, item.model_number, item.project_name, item.make_oem,
    item.phase, item.family, item.category, item.owner, item.owner_employee,
    item.user, item.received_date, item.status, item.last_tested,
    item.toner_avl, item.location_rack, item.floor, item.remarks
  ];

  try {
    const [result] = await pool.query(query, values);
    return result;
  } catch (err) {
    console.error('Insert error:', err.message);
  }
};

module.exports = { insertInventoryItem };
