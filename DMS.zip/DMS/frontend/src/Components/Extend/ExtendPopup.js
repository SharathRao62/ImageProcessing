import React, { useState } from 'react';
import './ExtendPopup.css';

const ExtendPopup = ({ user, onClose }) => {
  const [selectedDate, setSelectedDate] = useState('');

  const handleSubmit = async () => {
    if (!selectedDate) {
      alert('Please select a date');
      return;
    }

    const requestData = {
      device_name: user.name,
      model_number: `Model_${user.id}`,
      extend_date: selectedDate,
    };

    try {
      const response = await fetch('https://your-backend-api.com/extend-request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestData),
      });

      if (response.ok) {
        alert(`Extension requested for ${user.name} until ${selectedDate}`);
        onClose();
      } else {
        alert('Failed to send extension request');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred while sending the request');
    }
  };

  return (
    <div className="popup-overlay">
      <div className="popup-box">
        <h2>Extend for {user.name}</h2>
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
        />
        <div className="popup-buttons">
          <button className="submit-btn" onClick={handleSubmit}>
            Submit
          </button>
          <button className="cancel-btn" onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExtendPopup;
