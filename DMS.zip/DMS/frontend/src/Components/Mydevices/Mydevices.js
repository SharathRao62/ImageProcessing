import React, { useEffect, useState } from 'react';
import './Mydevices.css'


const Device = () => {
  const [users, setUsers] = useState([]);
  

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((res) => res.json())
      .then((data) => setUsers(data))
      .catch((err) => console.error('API error:', err));
  }, []);

  return (
    <div className="dashboard-container">
      <h1>Dashboard</h1>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>SI NO</th>
              <th>Request Id</th>
              <th>Device Name</th>
              <th>Model Number</th>
              <th>Global RND No</th>
              <th>Category</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr key={user.id}>
                <td>{index + 1}</td>
                <td>REQ{user.id.toString().padStart(9, '0')}</td>
                <td>{user.name}</td>
                <td>Model_{user.id}</td>
                <td>GRND{1000 + user.id}</td>
                <td>{user.company.bs.split(' ')[0]}</td>
                <td> {user.address.street} </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

    
    </div>
  );
};

export default Device;
