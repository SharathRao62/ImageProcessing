// import React from 'react';
// import './Devices.css';
// // import PopupRequestForm from '../Popup/PopupRequestForm';

// const Device = () => {
//   // const [popupUser, setPopupUser] = useState(null);

//   // Sample device data (replace with real data from your backend or props if needed)
//   const deviceData = [
//     {
//       id:1,
//       device_name: 'Samsung HR_234',
//       model_number: 'HR_234',
//       request_id:'REQ627901035',
//       global_rnd_no: 'GRND12345',
//       category: 'Mobile',
//     },
//     {
//       id:2,
//       device_name: 'Dell Latitude',
//       model_number: 'DL_5500',
//       request_id:'REQ627901036',
//       global_rnd_no: 'GRND67890',
//       category: 'Laptop',
//     },
//   ];

//   return (
//     <div className="dashboard-container">
//       <h1>Dashboard</h1>

//       <div className="table-container">
//         <table>
//           <thead>
//             <tr>
//               <th>SI NO</th>
//               <th>Request Id</th>
//               <th>Device Name</th>
//               <th>Model Number</th>
//               <th>Global RND No</th>
//               <th>Category</th>
//               <th>Extend</th>
              
              
//             </tr>
//           </thead>
//           <tbody>
//             {deviceData.map((device, index) => (
//               <tr key={index}>
//                 <td>{device.id}</td>
//                 <td>{device.request_id}</td>
//                 <td>{device.device_name}</td>
//                 <td>{device.model_number}</td>
//                 <td>{device.global_rnd_no}</td>
//                 <td>{device.category}</td>

//                 <td>
//                   {/* <button
//                     className="request-button"
//                     onClick={() => setPopupUser(device.device_name)}
//                   >
//                     Request
//                   </button> */}
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>

//       {/* {popupUser && (
//         <PopupRequestForm
//           userName={popupUser}
//           onClose={() => setPopupUser(null)}
//         />
//       )} */}
//     </div>
//   );
// };

// export default Device;





import React, { useEffect, useState } from 'react';
import './Devices.css';
import ExtendPopup from '../Extend/ExtendPopup';

const Device = () => {
  const [users, setUsers] = useState([]);
  const [popupUser, setPopupUser] = useState(null);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((res) => res.json())
      .then((data) => setUsers(data))
      .catch((err) => console.error('API error:', err));
  }, []);

  return (
    <div className="dashboard-container">
      <h1>Dashboard</h1>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>SI NO</th>
              <th>Request Id</th>
              <th>Device Name</th>
              <th>Model Number</th>
              <th>Global RND No</th>
              <th>Category</th>
              <th>Extend</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr key={user.id}>
                <td>{index + 1}</td>
                <td>REQ{user.id.toString().padStart(9, '0')}</td>
                <td>{user.name}</td>
                <td>Model_{user.id}</td>
                <td>GRND{1000 + user.id}</td>
                <td>{user.company.bs.split(' ')[0]}</td>
                <td>
                  <button
                    className="request-button"
                    onClick={() => setPopupUser(user)}
                  >
                    Extend
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {popupUser && (
        <ExtendPopup user={popupUser} onClose={() => setPopupUser(null)} />
      )}
    </div>
  );
};

export default Device;
