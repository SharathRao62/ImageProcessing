import React, { useState } from 'react';
import './Login.css';
import axios from 'axios';
import {
  FaEnvelope,
  FaLock,
  FaEye,
  FaEyeSlash,
  FaExclamationCircle,
  FaUser,
} from 'react-icons/fa';
import Logo from 'D:/DMS/frontend/src/Assets/Logo.jpg';
import Page from '../Page/Page';

const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [errors, setErrors] = useState({});
  const [showGuideline, setShowGuideline] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    if (errors[name]) {
      const updatedErrors = { ...errors };
      delete updatedErrors[name];
      setErrors(updatedErrors);
    }

    if (name === 'password') {
      const updatedErrors = { ...errors };
      delete updatedErrors.length;
      delete updatedErrors.upper;
      delete updatedErrors.lowerDigit;
      delete updatedErrors.special;
      setErrors(updatedErrors);
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;

    if (name === 'email' && !value.trim()) {
      setErrors((prev) => ({ ...prev, email: 'Email cannot be blank' }));
    }

    if (name === 'password') {
      if (value.trim() === '') {
        setErrors((prev) => ({ ...prev, password: 'Password cannot be blank' }));
      } else {
        const updatedErrors = { ...errors };
        delete updatedErrors.password;
        setErrors(updatedErrors);

        if (!isLogin) {
          const newErrors = {};
          if (value.length < 8) newErrors.length = 'Password is too short';
          if (!/[A-Z]/.test(value)) newErrors.upper = 'Please enter a capital letter';
          if (!/[a-z]/.test(value) || !/\d/.test(value)) {
            newErrors.lowerDigit = 'Please enter lowercase letter and digit';
          }
          if (!/[@$!%*#?&]/.test(value)) {
            newErrors.special = 'Need a special character';
          }
          setErrors((prev) => ({ ...prev, ...newErrors }));
        }
      }
    }

    if (name === 'confirmPassword' && form.password !== value) {
      setErrors((prev) => ({ ...prev, confirmPassword: 'Passwords do not match' }));
    }

    if (name === 'name' && !value.trim()) {
      setErrors((prev) => ({ ...prev, name: 'Name cannot be blank' }));
    }
  };

  const handleSubmit = async () => {
    const newErrors = {};

    if (!form.email.trim()) newErrors.email = 'Email cannot be blank';
    if (!form.password.trim()) newErrors.password = 'Password cannot be blank';

    if (!isLogin) {
      if (!form.name.trim()) newErrors.name = 'Name cannot be blank';
      if (form.password !== form.confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match';
      }

      if (
        Object.keys(errors).some(
          (key) => !['email', 'password', 'confirmPassword', 'name'].includes(key)
        )
      ) {
        alert('Please fix the password errors');
        return;
      }
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors((prev) => ({ ...prev, ...newErrors }));
      return;
    }

    const apiUrl = isLogin
      ? 'http://localhost:5000/api/v1/login'
      : 'http://localhost:5000/api/v1/user_registration';

    const payload = {
      email: form.email,
      password: form.password,
      role: 'user',
      ...(isLogin ? {} : { name: form.name }),
    };

    try {
      const response = await axios.post(apiUrl, payload);

      if (response.status === 200 || response.status === 201) {
        alert(
          isLogin
            ? 'Login successful, user found in database!'
            : 'Registration successful, data saved in database!'
        );
        setForm({ name: '', email: '', password: '', confirmPassword: '' });

        if (isLogin) {
          setLoggedIn(true);
          
        } else {
          setIsLogin(true); // switch to login view after sign up
        }
      }

//    if (response.status === 200 || response.status === 201) {
//   const { name, email, token } = response.data.data;

//   // Save to localStorage
//   localStorage.setItem('userName', name);
//   localStorage.setItem('userEmail', email);
//   localStorage.setItem('authToken', token);

//   alert(
//     isLogin
//       ? 'Login successful, user found in database!'
//       : 'Registration successful, data saved in database!'
//   );

//   setForm({ name: '', email: '', password: '', confirmPassword: '' });

//   if (isLogin) {
//     setLoggedIn(true);
//   } else {
//     setIsLogin(true); // switch to login view after sign up
//   }
// }
    } catch (error) {
      console.error('API error:', error);
      alert(
        error.response?.data?.message ||
        (isLogin ? 'Login failed' : 'Registration failed')
      );
    }
  };

  if (loggedIn) {
    return (
      <div style={{ display: 'flex' }}>
        <Page />
      </div>
    );
  }

  return (
    <div className='maincontent'>
    <div className="login-page">
      <div className="form-container">
        <div className="left-side">
          <div className="logo">
            <img src={Logo} alt="Mphasis Logo" />
          </div>
          <h2>Welcome to login system</h2>
          <p>Sign in by entering the information below</p>

          {/* Name input (only in sign up) */}
          {!isLogin && (
            <>
              <div className="input-group">
                <FaUser />
                <input
                  type="text"
                  name="name"
                  placeholder="Name"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={form.name}
                />
              </div>
              {errors.name && (
                <div className="error-message">
                  <FaExclamationCircle className="error-icon" /> {errors.name}
                </div>
              )}
            </>
          )}

          {/* Email input */}
          <div className="input-group">
            <FaEnvelope />
            <input
              type="email"
              name="email"
              placeholder="Email"
              onChange={handleChange}
              onBlur={handleBlur}
              value={form.email}
            />
          </div>
          {errors.email && (
            <div className="error-message">
              <FaExclamationCircle className="error-icon" /> {errors.email}
            </div>
          )}

          {/* Password input */}
          <div className="input-group">
            <FaLock />
            <input
              type={showPassword ? 'text' : 'password'}
              name="password"
              placeholder="Password"
              onChange={handleChange}
              onBlur={handleBlur}
              onFocus={() => setShowGuideline(true)}
              value={form.password}
            />
            {showPassword ? (
              <FaEyeSlash className="eye-icon" onClick={() => setShowPassword(false)} />
            ) : (
              <FaEye className="eye-icon" onClick={() => setShowPassword(true)} />
            )}
          </div>

          {errors.password && (
            <div className="error-message">
              <FaExclamationCircle className="error-icon" /> {errors.password}
            </div>
          )}

          {!isLogin && showGuideline && (
            <p className="password-guideline">
              Password should be at least 8 characters including a number, lowercase letter, capital letter, and special character.
            </p>
          )}

          {!isLogin && (
            <ul className="error-list">
              {Object.entries(errors).map(([key, err], index) =>
                !['email', 'password', 'confirmPassword', 'name'].includes(key) ? (
                  <li key={index}>
                    <FaExclamationCircle className="error-icon" /> {err}
                  </li>
                ) : null
              )}
            </ul>
          )}

          {/* Confirm password input */}
          {!isLogin && (
            <>
              <div className="input-group">
                <FaLock />
                <input
                  type="password"
                  name="confirmPassword"
                  placeholder="Re-enter Password"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={form.confirmPassword}
                />
              </div>
              {errors.confirmPassword && (
                <div className="error-message">
                  <FaExclamationCircle className="error-icon" /> {errors.confirmPassword}
                </div>
              )}
            </>
          )}

          <button className="btn" onClick={handleSubmit}>
            {isLogin ? 'Login' : 'Sign Up'}
          </button>

          <p className="toggle-text">
            {isLogin ? "Don't have an account?" : 'Already have an account?'}{' '}
            <span onClick={() => setIsLogin(!isLogin)}>
              {isLogin ? 'Sign up' : 'Login'}
            </span>
          </p>
        </div>
        <div className="right-side"></div>
      </div>
    </div>
    </div>
  );
};

export default Login;
