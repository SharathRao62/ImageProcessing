import React, { useState } from 'react';
import './Dashboard.css';
import PopupRequestForm from '../Popup/PopupRequestForm';

const Dashboard = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState([]);
  const [popupData, setPopupData] = useState(null); // stores device_name and global_rnd_no
  const [error, setError] = useState('');

  const handleSearch = async () => {
    if (searchTerm.trim().length < 3) {
      setError('Please enter at least 3 letters.');
      setResults([]);
      return;
    }

    setError('');
    try {
      const response = await fetch('http://localhost:5000/api/v1/deviceSearch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ search_key: searchTerm }),
      });

      const result = await response.json();

      if (response.status === 404 || result.status === 404) {
        setResults([]);
        setError('No devices found.');
      } else if (response.ok && result.status === 200) {
        setResults(result.data);
      } else {
        setError('Unexpected error occurred.');
        setResults([]);
      }
    } catch (error) {
      console.error('Error fetching devices:', error);
      setError('Server error. Please try again later.');
      setResults([]);
    }
  };

  return (
    <div className="dashboard-container">
      <h1>Dashboard</h1>
      <div className="search-section">
        <input
          type="text"
          placeholder="Search by name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button onClick={handleSearch}>Search</button>
        {error && <p className="error-message">{error}</p>}
      </div>

      {results.length > 0 && (
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Device Name</th>
                <th>Model Number</th>
                <th>Global RND No</th>
                <th>Category</th>
                <th>Status</th>
                <th>Request</th>
              </tr>
            </thead>
            <tbody>
              {results.map((user) => (
                <tr key={user.id}>
                  <td>{user.device_name}</td>
                  <td>{user.model_number}</td>
                  <td>{user.global_rnd_no}</td>
                  <td>{user.category}</td>
                  <td>{user.street}</td>
                  <td>
                    <button
                      className="request-button"
                      onClick={() =>
                        setPopupData({
                          device_name: user.device_name,
                          global_rnd_no: user.global_rnd_no,
                          model_number:user.model_number,
                          category: user.category
                        })
                      }
                    >
                      Request
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {popupData && (
        <PopupRequestForm
          onClose={() => setPopupData(null)}
          deviceName={popupData.device_name}
          globalRndNo={popupData.global_rnd_no}
          model_number={popupData.model_number}
          category={popupData.category}
        />
      )}
    </div>
  );
};

export default Dashboard;





// import React, { useState } from 'react';
// import './Dashboard.css';
// import PopupRequestForm from '../Popup/PopupRequestForm';

// const Dashboard = () => {
//   const [searchTerm, setSearchTerm] = useState('');
//   const [results, setResults] = useState([]);
//   const [popupUser, setPopupUser] = useState(null);
//   const [error, setError] = useState('');

//   const handleSearch = async () => {
//     if (searchTerm.trim().length < 3) {
//       setError('Please enter at least 3 letters.');
//       setResults([]);
//       return;
//     }
  
//     setError('');
//     try {
//       const response = await fetch('http://localhost:5000/api/v1/deviceSearch', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({ search: searchTerm }),
//       });
  
//       const result = await response.json();
  
//       if (response.status === 404 || result.status === 404) {
//         setResults([]);
//         setError('No devices found.');
//       } else if (response.ok && result.status === 200) {
//         setResults(result.data);
//       } else {
//         setError('Unexpected error occurred.');
//         setResults([]);
//       }
//     } catch (error) {
//       console.error('Error fetching devices:', error);
//       setError('Server error. Please try again later.');
//       setResults([]);
//     }
//   };
  

//   return (
//     <div className="dashboard-container">
//       <h1>Dashboard</h1>
//       <div className="search-section">
//         <input
//           type="text"
//           placeholder="Search by name..."
//           value={searchTerm}
//           onChange={(e) => setSearchTerm(e.target.value)}
//         />
//         <button onClick={handleSearch}>Search</button>
//         {error && <p className="error-message">{error}</p>}
//       </div>

//       {results.length > 0 && (
//   <div className="table-container">
//     <table>
//       <thead>
//         <tr>
//           <th>Device Name</th>
//           <th>Model Number</th>
//           <th>Global RND No</th>
//           <th>Category</th>
//           <th>Request</th>
//         </tr>
//       </thead>
//       <tbody>
//         {results.map((device, index) => (
//           <tr key={index}>
//             <td>{device.device_name}</td>
//             <td>{device.model_number}</td>
//             <td>{device.global_rnd_no}</td>
//             <td>{device.category}</td>
//             <td>
//               <button
//                 className="request-button"
//                 onClick={() => setPopupUser(device.device_name)}
//               >
//                 Request
//               </button>
//             </td>
//           </tr>
//         ))}
//       </tbody>
//     </table>
//   </div>
// )}


//       {popupUser && (
//         <PopupRequestForm
//           userName={popupUser}
//           onClose={() => setPopupUser(null)}
//         />
//       )}
//     </div>
//   );
// };

// export default Dashboard;
