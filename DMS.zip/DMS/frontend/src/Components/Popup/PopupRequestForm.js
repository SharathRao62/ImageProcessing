// // components/PopupRequestForm.js
// import React, { useState } from 'react';
// import './PopupRequestForm.css';

// const PopupRequestForm = ({ onClose }) => {
//   const [form, setForm] = useState({
//     name: '',
//     cubic: '',
//     floor: '',
//     manager: '',
//     requestDate: '',
//   });

//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };

//   // const handleSubmit = async (e) => {
//   //   e.preventDefault();
  
//   //   try {
//   //     const response = await fetch('https://jsonplaceholder.typicode.com/users', {
//   //       method: 'POST',
//   //       headers: {
//   //         'Content-Type': 'application/json',
//   //       },
//   //       body: JSON.stringify(form),
//   //     });
  
//   //     const result = await response.json();
  
//   //     if (response.ok) {
//   //       alert(`Your registration is successful! Request ID: ${result.id}`);
//   //       onClose();
//   //     } else {
//   //       alert(`Failed: ${result.message}`);
//   //     }
//   //   } catch (error) {
//   //     console.error('Error submitting request:', error);
//   //     alert('An error occurred while submitting your request.');
//   //   }
//   // };



//   const handleSubmit = async (e) => {
//     e.preventDefault();
  
//     try {
//       const response = await fetch('http://localhost:5000/api/v1/request', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(form),
//       });
  
//       const result = await response.json();
  
//       if (result.status === 200 && result.message === "Success") {
//         alert(`Your request is successful! Registration Number: ${result.registrationNumber}`);
//         onClose();
//       } else {
//         alert(`Failed: ${result.message || 'Unknown error occurred.'}`);
//       }
//     } catch (error) {
//       console.error('Error submitting request:', error);
//       alert('An error occurred while submitting your request.');
//     }
//   };
  
  

  
  
//   return (
//     <div className="popup-overlay">
//       <div className="popup-form">
//         <h2>Device Request</h2>
//         <form onSubmit={handleSubmit}>
//           <input name="name" placeholder="Name" onChange={handleChange} required />
//           <input name="cubic" placeholder="Cubic Number" onChange={handleChange} required />
//           <input name="floor" placeholder="Floor Number" onChange={handleChange} required />
//           <input name="manager" placeholder="Manager Name" onChange={handleChange} required />
//           <input type="date" name="requestDate" onChange={handleChange} value={form.requestDate} required />
//           <input name="email" placeholder='Email Id' onChange={handleChange} required/>
//           <div className="form-actions">
//             <button type="submit">Submit</button>
//             <button type="button" onClick={onClose} className="cancel">Cancel</button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default PopupRequestForm;


import React, { useState } from 'react';
import './PopupRequestForm.css'

const PopupRequestForm = ({ onClose, deviceName, globalRndNo,modelNumber,category }) => {
  const [form, setForm] = useState({
    name: '',
    desk: '',
    floor: '',
    tower: '',
    request_date: '',
    email: '',
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const formatDate = (isoDate) => {
    const [year, month, day] = isoDate.split("-");
    return `${day}-${month}-${year}`;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formattedRequest = {
      ...form,
      global_rnd_no: globalRndNo,
      device_name: deviceName,
      model_number:modelNumber,
      category: category,
      request_date: formatDate(form.request_date),
      //email shoulbe  pass

    };

    try {
      const response = await fetch('http://localhost:5000/api/v1/request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formattedRequest),
      });

      const result = await response.json();

      if (result.status === 200 && result.message === 'Success') {
        alert(`Your request is successful! Request ID: ${result.requestId}`);
        onClose();
      } else {
        alert(`Failed: ${result.message || 'Unknown error occurred.'}`);
      }
    } catch (error) {
      console.error('Error submitting request:', error);
      alert('An error occurred while submitting your request.');
    }
  };

  return (
    <div className="popup-overlay">
      <div className="popup-form">
        <h2>Device Request</h2>
        <form onSubmit={handleSubmit}>
          <input name="name" placeholder="Name" onChange={handleChange} required />
          <input name="desk" placeholder="Cubic Number" onChange={handleChange} required />
          <input name="floor" placeholder="Floor Number" onChange={handleChange} required />
          <input name="tower" placeholder="Manager Name" onChange={handleChange} required />
          <input type="date" name="request_date" value={form.request_date} onChange={handleChange} required />
          <input name="email" placeholder="Email ID" onChange={handleChange} required />

          <div className="form-actions">
            <button type="submit">Submit</button>
            <button type="button" onClick={onClose} className="cancel">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PopupRequestForm;
