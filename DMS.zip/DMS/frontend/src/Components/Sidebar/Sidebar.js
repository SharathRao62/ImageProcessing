import React, { useState } from 'react';
import './Sidebar.css';
import { FaTachometerAlt, FaLaptop, FaChevronDown } from 'react-icons/fa';
import Logo from 'D:/DMS/frontend/src/Assets/Logo.jpg';
import { Link } from 'react-router-dom';


const Sidebar = () => {
  const [isDevicesOpen, setIsDevicesOpen] = useState(false);

  const toggleDevices = () => {
    setIsDevicesOpen(!isDevicesOpen);
  };

  return (
    <div className="sidebar">
      <img src={Logo} alt="Logo" className="logo-pic" />
      <ul className="menu">
        <li>
          <FaTachometerAlt className="icon" />
          <Link to="/dashboard" className="span1">Dashboard</Link>
        </li>
        <li onClick={toggleDevices} className="dropdown">
          <FaLaptop className="icon" />
          <span className="span1">Devices</span>
          <FaChevronDown className={`chevron ${isDevicesOpen ? 'rotate' : ''}`} />
        </li>
        {isDevicesOpen && (
          <ul className="submenu">
            <li>
              
              <Link className='span1' to="/Mydevices">My Devices</Link>
             

            </li>
             <li>
              <Link className='span1' to="/Devices">Extend devices</Link>
             </li>
          </ul>
        )}
      </ul>
    </div>
  );
};

export default Sidebar;
