import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './Components/Login/Login';
import Page from './Components/Page/Page';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLoginSuccess = () => {
    setIsLoggedIn(true);
  };

  return (
    <Router>
      <Routes>
        {!isLoggedIn ? (
          <Route path="/*" element={<Login onLoginSuccess={handleLoginSuccess} />} />
        ) : (
          <Route path="/*" element={<Page />} />
        )}
      </Routes>
    </Router>
  );
};

export default App;
