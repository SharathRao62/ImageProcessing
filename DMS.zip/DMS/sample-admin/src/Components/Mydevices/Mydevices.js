import React from 'react'

const Mydevices = () => {
  return (
    <div>Mydevices</div>
  )
}

export default Mydevices