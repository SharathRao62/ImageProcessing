// import React, { useState } from 'react';
// import './Sidebar.css';
// import { FaTachometerAlt, FaLaptop, FaChevronDown } from 'react-icons/fa';
// // import Logo from 'D:/DMS/frontend/src/Assets/Logo.jpg';
// import { Link } from 'react-router-dom';


// const Sidebar = () => {
//   const [isDevicesOpen, setIsDevicesOpen] = useState(false);

//   const toggleDevices = () => {
//     setIsDevicesOpen(!isDevicesOpen);
//   };

//   return (
//     <div className="sidebar">
//       {/* <img src={Logo} alt="Logo" className="logo-pic" /> */}
//       <ul className="menu">
//         <li>
//           <FaTachometerAlt className="icon" />
//           <Link to="/dashboard" className="span1">Dashboard</Link>
//         </li>
//         <li onClick={toggleDevices} className="dropdown">
//           <FaLaptop className="icon" />
//           <span className="span1">Devices</span>
//           <FaChevronDown className={`chevron ${isDevicesOpen ? 'rotate' : ''}`} />
//         </li>
//         {isDevicesOpen && (
//           <ul className="submenu">
//             <li>
              
//               <Link className='span1' to="/Mydevices">My Devices</Link>
             

//             </li>
//              <li>
//               <Link className='span1' to="/Devices">Extend devices</Link>
//              </li>
//           </ul>
//         )}
//       </ul>
//     </div>
//   );
// };

// export default Sidebar;



import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Sidebar.css";
import {
  FaTachometerAlt,
  FaMicrochip,
  FaClipboardList,
  FaCheckCircle,
  FaTimesCircle,
  FaUser,
  FaChevronDown,
  FaChevronUp,
} from "react-icons/fa";

export default function Sidebar() {
  const [activeMenu, setActiveMenu] = useState(""); // Track active manually
  const [showRequestsMenu, setShowRequestsMenu] = useState(false);

  const handleMenuClick = (menu) => {
    setActiveMenu(menu);
    if (menu === "requests") {
      setShowRequestsMenu(!showRequestsMenu);
    } else {
      setShowRequestsMenu(false); // Collapse submenu when clicking outside
    }
  };

  return (
    <div className="sidebar">
      <h3>Admin Panel</h3>
      <ul>
        <li className={activeMenu === "dashboard" ? "active" : ""} onClick={() => handleMenuClick("dashboard")}>
          <Link to="/Dashboard">
            <FaTachometerAlt className="icon" />
            Dashboard
          </Link>
        </li>
        <li className={activeMenu === "devices" ? "active" : ""} onClick={() => handleMenuClick("devices")}>
          <Link to="/devices">
            <FaMicrochip className="icon" />
            Devices
          </Link>
        </li>
        <li onClick={() => handleMenuClick("requests")}>
          <div className={activeMenu === "requests" ? "active" : ""}>
            <FaClipboardList className="icon" />
            Requests {showRequestsMenu ? <FaChevronUp /> : <FaChevronDown />}
          </div>
        </li>

        {showRequestsMenu && (
          <ul className="submenu">
            <li className={activeMenu === "approval" ? "active" : ""} onClick={() => setActiveMenu("approval")}>
              <Link to="/requests/approval">
                <FaCheckCircle className="icon" />
                Approval
              </Link>
            </li>
            <li className={activeMenu === "deny" ? "active" : ""} onClick={() => setActiveMenu("deny")}>
              <Link to="/requests/deny">
                <FaTimesCircle className="icon" />
                Deny
              </Link>
            </li>
          </ul>
        )}

        <li className={activeMenu === "users" ? "active" : ""} onClick={() => handleMenuClick("users")}>
          <Link to="/users">
            <FaUser className="icon" />
            Users
          </Link>
        </li>
      </ul>
    </div>
  );
}



