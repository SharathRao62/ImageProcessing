import React from 'react'

const Devices = () => {
  return (
    <div>Devices</div>
  )
}

export default Devices