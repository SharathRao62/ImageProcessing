const dbconfig = require('../config/dbConfig')
const Sequelize = require('sequelize')

var user_requested_device = dbconfig.define('user_requested_device', {

    id: {
        type: Sequelize.INTEGER,
        // allowNull: false
        primaryKey: true
    },
    name: Sequelize.STRING,   //connecting mysql with node js server
    desk: Sequelize.STRING,
    floor: Sequelize.STRING,
    tower: Sequelize.STRING,
    email: Sequelize.STRING,
    request_id: Sequelize.STRING,
    device_name: Sequelize.STRING,
    request_date: Sequelize.DATE,
    global_rnd_no: Sequelize.STRING,
    createdTime: Sequelize.DATE,
    updatedTime: Sequelize.DATE,
},
    {
        updatedAt: 'updatedTime',
        createdAt: 'createdTime',
        freezeTableName: true,
    });

module.exports = user_requested_device
