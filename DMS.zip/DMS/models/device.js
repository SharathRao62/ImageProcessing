const dbconfig = require('../config/dbConfig')
const Sequelize = require('sequelize')

var device = dbconfig.define('device', {

    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    item_barcode: Sequelize.STRING,
    global_rnd_no: Sequelize.STRING,
    bond_no: Sequelize.STRING,
    hp_id: Sequelize.STRING,
    serial_number: Sequelize.STRING,
    model_number: Sequelize.STRING,
    project_name: Sequelize.STRING,
    make_oem: Sequelize.STRING,
    phase: Sequelize.STRING,
    family: Sequelize.STRING,
    category: Sequelize.STRING,
    owner: Sequelize.STRING,
    owner_employee: Sequelize.STRING,
    user: Sequelize.STRING,
    received_date: Sequelize.DATE,
    status: Sequelize.STRING,
    last_tested: Sequelize.DATE,
    toner_avl: Sequelize.STRING,
    location_rack: Sequelize.STRING,
    floor: Sequelize.INTEGER,
    remarks: Sequelize.STRING,
    createdTime: Sequelize.DATE,
    updatedTime: Sequelize.DATE

},
    {
        updatedAt: 'updatedTime',
        createdAt: 'createdTime',
        freezeTableName: true,
    });

module.exports = device
