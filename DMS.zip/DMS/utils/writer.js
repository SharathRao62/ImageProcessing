 
// const { aesEncrypt } = require("./encryption");
 
var ResponsePayload = function (code, payload) {
    this.code = code;
    this.payload = payload;
  };
 
  exports.respondWithCode = function (code, payload) {
    return new ResponsePayload(code, payload);
  };
 
  var writeJson = (exports.writeJson = async function (response, arg1, arg2) {
    var code;
    var payload;
 
    // if (arg1.status != 200 && !arg1.errMsg) {
    //   arg1.errMsg = "something went wrong";
    // }
    if (arg1?.err_stage) {
      delete arg1.err_stage;
    }
 
    if (arg1 && arg1 instanceof ResponsePayload) {
      writeJson(response, arg1.payload, arg1.code);
      return;
    }
 
    if (arg2 && Number.isInteger(arg2)) {
      code = arg2;
    } else {
      if (arg1 && Number.isInteger(arg1)) {
        code = arg1;
      }
    }
    if (code && arg1) {
      payload = arg1;
    } else if (arg1) {
      payload = arg1;
    }
 
    if (!code) {
      // if no response code given, we default to 200
      code = 200;
    }
 
    // // Check if encryption is enabled before sending response
    // if (response?.config && response?.config?.encryption === true) {
    //   const securityKey = response?.config?.encryptionKey;
    //   payload = { data: await aesEncrypt(payload, securityKey) };
    // }
 
    if (typeof payload === "object") {
      payload = JSON.stringify(payload, null, 2);
    }
    // delete response.config;
    response.writeHead(code, { "Content-Type": "application/json" });
    response.end(payload);
  });
 